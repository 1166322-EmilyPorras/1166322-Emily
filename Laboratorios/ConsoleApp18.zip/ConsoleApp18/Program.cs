﻿using System;

namespace ConsoleApp18
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //EJERCICIO 21 Y 22

            Console.WriteLine("(1). x^5-x^2+7x-1");
            Console.WriteLine("(2). 4x^3-3x^2+2x-5");
            Console.WriteLine("(3). (5√3)*2x-1");
            Console.WriteLine("Ingrese un valor para 'X' y valuar en las ecuaciones anteriores");
            double x = double.Parse(Console.ReadLine());

            double a = 3 * (Math.Pow(x, 5)) - (Math.Pow(x, 2)) + 7 * x - 1;  //3x^5-x^2+7x-1
            double b = 4 * (Math.Pow(x, 3)) - 3 * (Math.Pow(x, 2)) + 2 * x - 5; //4x^3-3x^2+2x-5
            double c = 5 * (Math.Sqrt(3)) * 2 * x - 1; //(5√3)*2x-1

            Console.WriteLine("f(" + x + ") es: " + a);
            Console.WriteLine("f(" + x + ") es: " + b);
            Console.WriteLine("f(" + x + ") es: " + c);

            Console.ReadKey();

            //EJERCICIO 24

            Console.WriteLine("----Hola de nuevo----");
            Console.WriteLine("Ingrese el presupuesto anual de la fábrica: ");
            double presupuesto = double.Parse(Console.ReadLine());

            double rh = presupuesto * 0.50;
            double m = presupuesto * 0.25;
            double e = presupuesto * 0.15;
            double p = presupuesto * 0.10;

            Console.WriteLine("Le pertenece: " + rh + " a recursos humanos, " + m + " a manufactura, " + e + " a empaquetado, y " + p + " a publicidad.");

            Console.ReadKey();

            //EJERCICIO 25

            Console.WriteLine("----Mucho gusto----");
            Console.WriteLine("¿Cuanto es el salario del empleado (SIN DESCUENTOS)?");
            double sueldo = double.Parse(Console.ReadLine());

            double i = sueldo * 0.09;
            double af = sueldo * 0.07;
            double r = sueldo * 0.10;

            double total = sueldo - (i + af + r);
            Console.WriteLine("El sueldo neto a pagarle al empleado es: " + total);

            Console.ReadKey();

            //EJERCICIO 35

            Console.WriteLine("----¡QUE BUENO QUE AUN SIGUES AQUI----");
            Console.WriteLine("Este programa es de operadore aritmeticos, si quiere utilizar alguno..PULSA..");
            Console.WriteLine("(+) SUMA");
            Console.WriteLine("(-) RESTA");
            Console.WriteLine("(*) MULTIPLICACION");
            Console.WriteLine("(/) DIVISION");
            Console.WriteLine("(%) MOD");
            Console.WriteLine("Escriba el operador con respecto a la operacion que desea llevar a cabo: ");
            string operador = (Console.ReadLine());

            if (operador == "+")
            {
                Console.WriteLine("Ingrese un primer numero: ");
                double n1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese un segundo numero: ");
                double n2 = double.Parse(Console.ReadLine());

                double rs = n1 + n2;
                Console.WriteLine("La respuesta a la suma es: " + rs);
            }
            else if (operador == "-")
            {
                Console.WriteLine("Ingrese un primer numero: ");
                double n1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese un segundo numero: ");
                double n2 = double.Parse(Console.ReadLine());

                double rr = n1 - n2;
                Console.WriteLine("La respuesta a la resta es: " + rr);
            }
            else if (operador == "*")
            {
                Console.WriteLine("Ingrese un primer numero: ");
                double n1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese un segundo numero: ");
                double n2 = double.Parse(Console.ReadLine());

                double rm = n1 * n2;
                Console.WriteLine("La respuesta a la multiplicacion es: " + rm);
            }
            else if (operador == "/")
            {
                Console.WriteLine("Ingrese un primer numero: ");
                double n1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese un segundo numero: ");
                double n2 = double.Parse(Console.ReadLine());

                if (n2 == 0)
                {
                    Console.WriteLine("No existe la division entre 0");
                }
                else
                {
                    double rd = n1 / n2;
                    Console.WriteLine("La respuesta a la division es: " + rd);
                }
            }
            else if (operador == "%")
            {
                Console.WriteLine("Ingrese un primer numero: ");
                double n1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese un segundo numero: ");
                double n2 = double.Parse(Console.ReadLine());

                double rmod = n1 % n2;
                Console.WriteLine("El residuo de la division es: " + rmod);
            }
            Console.ReadKey();

            //EJERCICIO 11

            Console.WriteLine("------Sigue un poco mas....¡ANIMOSSS!-------");
            Console.WriteLine("Ingrese el precio del articulo: ");
            double precio = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la cantidad que va adquirir el articulo: ");
            double cantidad = double.Parse(Console.ReadLine());

            double subt = precio * cantidad;

            if(subt > 1000)
            {
                double tot = subt - (subt * 0.15);
                Console.WriteLine("Su total a paga es: " + tot);

            }else if(subt < 1000)
            {
                double tot2 = subt + (subt * 0.13);
                Console.WriteLine("Su total a pagar es: " + tot2);
            }
            Console.ReadKey();

            //EJERCICIO 13 CON FOR

            Console.WriteLine("-----Has llegado hasta aquí... ¡QUE ALEGREE!-------");
            Console.WriteLine("Sumaresmos los primeros 100 numeros naturales con la estructura FOR");
            int suma = 0;

            for (int j = 1; j <= 100; j++)
            {
                suma = suma + j;
            }
            Console.WriteLine("La suma de los primeros 100 numeros naturales es: " + suma);
            Console.ReadKey();

            //CON WHILE

            Console.WriteLine("-----¡MAGNIFICO!-------");
            Console.WriteLine("Sumaresmos los primeros 100 numeros naturales con la estructura WHILE");

            int sum = 0, cont = 0;

            while (cont <= 100)
            {
                sum = sum + cont;
                cont = cont + 1;

            }
            Console.WriteLine("La suma de los primeros 100 numeros naturales es: " + suma);
            Console.ReadKey();

            //CON DO WHILE

            Console.WriteLine("-----AQUI FALTA ALGUIEN IMPORTANTE-----");
            Console.WriteLine("Sumaresmos los primeros 100 numeros naturales con la estructura DO-WHILE");
            do
            {
                int sum2 = 0, cont2 = 0;
                sum2 = sum2 + cont2;
                cont2 = cont2 + 1;

            }while(cont <=100);

            Console.WriteLine("La suma de los primeros 100 numeros naturales es: " + suma);
            Console.ReadKey();

            Console.WriteLine("ADIOS :)");

            Console.ReadKey();

        }
    }
}
