﻿namespace Proyecto_Final_IP
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.AvanzarA2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.EscogerM3 = new System.Windows.Forms.RadioButton();
            this.EscogerM1 = new System.Windows.Forms.RadioButton();
            this.Jugador1Print = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.BalanceM3 = new System.Windows.Forms.NumericUpDown();
            this.SinergiaM3 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.ElixirM3 = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.CalcularVidaM3 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.CalcularDanoM3 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.M3 = new System.Windows.Forms.Label();
            this.BalanceM1 = new System.Windows.Forms.NumericUpDown();
            this.SinergiaM1 = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.ElixirM1 = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.CalcularVidaM1 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.CalcularDanoM1 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.M1 = new System.Windows.Forms.Label();
            this.OponenteDesignado = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Nota = new System.Windows.Forms.Label();
            this.ObtenerUser = new System.Windows.Forms.Button();
            this.UsuarioDesignado = new System.Windows.Forms.Label();
            this.ElejirEquipo = new System.Windows.Forms.ComboBox();
            this.EscribirNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.EmpezarP = new System.Windows.Forms.Button();
            this.EscogerM4 = new System.Windows.Forms.RadioButton();
            this.EscogerM2 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.BalanceM4 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.Jugador2Print = new System.Windows.Forms.Label();
            this.SinergiaM4 = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.ElixirM4 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.CalcularVidaM4 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.CalcularDanoM4 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.M4 = new System.Windows.Forms.Label();
            this.DefensaM3 = new System.Windows.Forms.NumericUpDown();
            this.BalanceM2 = new System.Windows.Forms.NumericUpDown();
            this.SinergiaM2 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ElixirM2 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.CalcularVidaM2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.CalcularDanoM2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.M2 = new System.Windows.Forms.Label();
            this.PicM4 = new System.Windows.Forms.PictureBox();
            this.PicM2 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.BInicio = new System.Windows.Forms.Button();
            this.IrACambiar = new System.Windows.Forms.Button();
            this.MJ2 = new System.Windows.Forms.Label();
            this.MJ1 = new System.Windows.Forms.Label();
            this.J2 = new System.Windows.Forms.Label();
            this.PS1 = new System.Windows.Forms.Label();
            this.PS0 = new System.Windows.Forms.Label();
            this.ElixirJ2 = new System.Windows.Forms.Label();
            this.BalanceJ1 = new System.Windows.Forms.Label();
            this.ElixirJ1 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.BalanceJ2 = new System.Windows.Forms.Label();
            this.SinergiaJ2 = new System.Windows.Forms.Label();
            this.VidaJ2 = new System.Windows.Forms.Label();
            this.DanoJ2 = new System.Windows.Forms.Label();
            this.SinergiaJ1 = new System.Windows.Forms.Label();
            this.VidaJ1 = new System.Windows.Forms.Label();
            this.DanoJ1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.MazoGanador = new System.Windows.Forms.Label();
            this.J1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label90 = new System.Windows.Forms.Label();
            this.NuevaCarta = new System.Windows.Forms.ComboBox();
            this.NuevoMazo = new System.Windows.Forms.ComboBox();
            this.CambioCarta = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.EmpezarNuevo = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.MazoACambiar = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.M2Cambio = new System.Windows.Forms.Label();
            this.M1Cambio = new System.Windows.Forms.Label();
            this.J2Cambio = new System.Windows.Forms.Label();
            this.NuevaJ2 = new System.Windows.Forms.Label();
            this.NuevaJ1 = new System.Windows.Forms.Label();
            this.EJ2 = new System.Windows.Forms.Label();
            this.BJ1 = new System.Windows.Forms.Label();
            this.EJ1 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.BJ2 = new System.Windows.Forms.Label();
            this.SJ2 = new System.Windows.Forms.Label();
            this.VJ2 = new System.Windows.Forms.Label();
            this.DJ2 = new System.Windows.Forms.Label();
            this.SJ1 = new System.Windows.Forms.Label();
            this.VJ1 = new System.Windows.Forms.Label();
            this.DJ1 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.J1Cambio = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DefensaM3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicM4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicM2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(30, 31);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(919, 711);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkMagenta;
            this.tabPage1.Controls.Add(this.AvanzarA2);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.EscogerM3);
            this.tabPage1.Controls.Add(this.EscogerM1);
            this.tabPage1.Controls.Add(this.Jugador1Print);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.BalanceM3);
            this.tabPage1.Controls.Add(this.SinergiaM3);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.ElixirM3);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Controls.Add(this.CalcularVidaM3);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.CalcularDanoM3);
            this.tabPage1.Controls.Add(this.label36);
            this.tabPage1.Controls.Add(this.M3);
            this.tabPage1.Controls.Add(this.BalanceM1);
            this.tabPage1.Controls.Add(this.SinergiaM1);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.ElixirM1);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.CalcularVidaM1);
            this.tabPage1.Controls.Add(this.label42);
            this.tabPage1.Controls.Add(this.CalcularDanoM1);
            this.tabPage1.Controls.Add(this.label44);
            this.tabPage1.Controls.Add(this.M1);
            this.tabPage1.Controls.Add(this.OponenteDesignado);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.Nota);
            this.tabPage1.Controls.Add(this.ObtenerUser);
            this.tabPage1.Controls.Add(this.UsuarioDesignado);
            this.tabPage1.Controls.Add(this.ElejirEquipo);
            this.tabPage1.Controls.Add(this.EscribirNombre);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(863, 682);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Registro";
            // 
            // AvanzarA2
            // 
            this.AvanzarA2.BackColor = System.Drawing.Color.DeepPink;
            this.AvanzarA2.Location = new System.Drawing.Point(393, 620);
            this.AvanzarA2.Name = "AvanzarA2";
            this.AvanzarA2.Size = new System.Drawing.Size(98, 36);
            this.AvanzarA2.TabIndex = 87;
            this.AvanzarA2.Text = "Siguiente";
            this.AvanzarA2.UseVisualStyleBackColor = false;
            this.AvanzarA2.Click += new System.EventHandler(this.AvanzarA2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Pink;
            this.label7.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(203, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(466, 33);
            this.label7.TabIndex = 86;
            this.label7.Text = "Registro de los Jugadores";
            // 
            // EscogerM3
            // 
            this.EscogerM3.AutoSize = true;
            this.EscogerM3.BackColor = System.Drawing.Color.Crimson;
            this.EscogerM3.Location = new System.Drawing.Point(754, 381);
            this.EscogerM3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EscogerM3.Name = "EscogerM3";
            this.EscogerM3.Size = new System.Drawing.Size(46, 20);
            this.EscogerM3.TabIndex = 84;
            this.EscogerM3.TabStop = true;
            this.EscogerM3.Text = "M3";
            this.EscogerM3.UseVisualStyleBackColor = false;
            this.EscogerM3.CheckedChanged += new System.EventHandler(this.EscogerM2_CheckedChanged_2);
            // 
            // EscogerM1
            // 
            this.EscogerM1.AutoSize = true;
            this.EscogerM1.BackColor = System.Drawing.Color.Crimson;
            this.EscogerM1.Location = new System.Drawing.Point(305, 381);
            this.EscogerM1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EscogerM1.Name = "EscogerM1";
            this.EscogerM1.Size = new System.Drawing.Size(46, 20);
            this.EscogerM1.TabIndex = 83;
            this.EscogerM1.TabStop = true;
            this.EscogerM1.Text = "M1";
            this.EscogerM1.UseVisualStyleBackColor = false;
            this.EscogerM1.CheckedChanged += new System.EventHandler(this.EscogerM1_CheckedChanged_1);
            // 
            // Jugador1Print
            // 
            this.Jugador1Print.AutoSize = true;
            this.Jugador1Print.BackColor = System.Drawing.Color.Aqua;
            this.Jugador1Print.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Jugador1Print.Location = new System.Drawing.Point(45, 286);
            this.Jugador1Print.Name = "Jugador1Print";
            this.Jugador1Print.Size = new System.Drawing.Size(43, 24);
            this.Jugador1Print.TabIndex = 82;
            this.Jugador1Print.Text = "J1...";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.LightPink;
            this.label28.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(39, 233);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(394, 27);
            this.label28.TabIndex = 81;
            this.label28.Text = "Escoge tu mazo para la partida";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(477, 453);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(233, 145);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 80;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = global::Proyecto_Final_IP.Properties.Resources.mazo_1;
            this.pictureBox2.Location = new System.Drawing.Point(44, 453);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(233, 145);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 79;
            this.pictureBox2.TabStop = false;
            // 
            // BalanceM3
            // 
            this.BalanceM3.BackColor = System.Drawing.Color.SpringGreen;
            this.BalanceM3.Enabled = false;
            this.BalanceM3.Location = new System.Drawing.Point(754, 571);
            this.BalanceM3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BalanceM3.Name = "BalanceM3";
            this.BalanceM3.Size = new System.Drawing.Size(61, 22);
            this.BalanceM3.TabIndex = 78;
            this.BalanceM3.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // SinergiaM3
            // 
            this.SinergiaM3.BackColor = System.Drawing.Color.SpringGreen;
            this.SinergiaM3.Enabled = false;
            this.SinergiaM3.Location = new System.Drawing.Point(754, 488);
            this.SinergiaM3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SinergiaM3.Name = "SinergiaM3";
            this.SinergiaM3.Size = new System.Drawing.Size(61, 22);
            this.SinergiaM3.TabIndex = 77;
            this.SinergiaM3.Value = new decimal(new int[] {
            69,
            0,
            0,
            0});
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Crimson;
            this.label30.Location = new System.Drawing.Point(752, 552);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(60, 16);
            this.label30.TabIndex = 76;
            this.label30.Text = "Balance:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Crimson;
            this.label31.Location = new System.Drawing.Point(752, 469);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(60, 16);
            this.label31.TabIndex = 75;
            this.label31.Text = "Sinergia:";
            // 
            // ElixirM3
            // 
            this.ElixirM3.BackColor = System.Drawing.Color.SpringGreen;
            this.ElixirM3.DecimalPlaces = 1;
            this.ElixirM3.Enabled = false;
            this.ElixirM3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ElixirM3.Location = new System.Drawing.Point(608, 418);
            this.ElixirM3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ElixirM3.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ElixirM3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ElixirM3.Name = "ElixirM3";
            this.ElixirM3.Size = new System.Drawing.Size(61, 22);
            this.ElixirM3.TabIndex = 74;
            this.ElixirM3.Value = new decimal(new int[] {
            34,
            0,
            0,
            65536});
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label32.Location = new System.Drawing.Point(475, 418);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 16);
            this.label32.TabIndex = 73;
            this.label32.Text = "Elixir Promedio:";
            // 
            // CalcularVidaM3
            // 
            this.CalcularVidaM3.AutoSize = true;
            this.CalcularVidaM3.BackColor = System.Drawing.Color.SpringGreen;
            this.CalcularVidaM3.Location = new System.Drawing.Point(605, 385);
            this.CalcularVidaM3.Name = "CalcularVidaM3";
            this.CalcularVidaM3.Size = new System.Drawing.Size(88, 16);
            this.CalcularVidaM3.TabIndex = 72;
            this.CalcularVidaM3.Text = "Puntos Vida...";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label34.Location = new System.Drawing.Point(475, 385);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(101, 16);
            this.label34.TabIndex = 71;
            this.label34.Text = "Puntos de Vida:";
            // 
            // CalcularDanoM3
            // 
            this.CalcularDanoM3.AutoSize = true;
            this.CalcularDanoM3.BackColor = System.Drawing.Color.SpringGreen;
            this.CalcularDanoM3.Location = new System.Drawing.Point(605, 356);
            this.CalcularDanoM3.Name = "CalcularDanoM3";
            this.CalcularDanoM3.Size = new System.Drawing.Size(91, 16);
            this.CalcularDanoM3.TabIndex = 70;
            this.CalcularDanoM3.Text = "Puntos daño...";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label36.Location = new System.Drawing.Point(475, 356);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(106, 16);
            this.label36.TabIndex = 69;
            this.label36.Text = "Puntos de Daño:";
            // 
            // M3
            // 
            this.M3.AutoSize = true;
            this.M3.BackColor = System.Drawing.Color.Chartreuse;
            this.M3.Font = new System.Drawing.Font("PanRoman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.M3.Location = new System.Drawing.Point(475, 327);
            this.M3.Name = "M3";
            this.M3.Size = new System.Drawing.Size(256, 18);
            this.M3.TabIndex = 68;
            this.M3.Text = "Sudden Death Loon Freeze Valk";
            // 
            // BalanceM1
            // 
            this.BalanceM1.BackColor = System.Drawing.Color.SpringGreen;
            this.BalanceM1.Enabled = false;
            this.BalanceM1.Location = new System.Drawing.Point(306, 571);
            this.BalanceM1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BalanceM1.Name = "BalanceM1";
            this.BalanceM1.Size = new System.Drawing.Size(61, 22);
            this.BalanceM1.TabIndex = 67;
            this.BalanceM1.Value = new decimal(new int[] {
            88,
            0,
            0,
            0});
            // 
            // SinergiaM1
            // 
            this.SinergiaM1.BackColor = System.Drawing.Color.SpringGreen;
            this.SinergiaM1.Enabled = false;
            this.SinergiaM1.Location = new System.Drawing.Point(306, 489);
            this.SinergiaM1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SinergiaM1.Name = "SinergiaM1";
            this.SinergiaM1.Size = new System.Drawing.Size(61, 22);
            this.SinergiaM1.TabIndex = 66;
            this.SinergiaM1.Value = new decimal(new int[] {
            65,
            0,
            0,
            0});
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Crimson;
            this.label38.Location = new System.Drawing.Point(304, 553);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(60, 16);
            this.label38.TabIndex = 65;
            this.label38.Text = "Balance:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Crimson;
            this.label39.Location = new System.Drawing.Point(304, 469);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(60, 16);
            this.label39.TabIndex = 64;
            this.label39.Text = "Sinergia:";
            // 
            // ElixirM1
            // 
            this.ElixirM1.BackColor = System.Drawing.Color.SpringGreen;
            this.ElixirM1.DecimalPlaces = 1;
            this.ElixirM1.Enabled = false;
            this.ElixirM1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ElixirM1.Location = new System.Drawing.Point(175, 422);
            this.ElixirM1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ElixirM1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ElixirM1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ElixirM1.Name = "ElixirM1";
            this.ElixirM1.Size = new System.Drawing.Size(61, 22);
            this.ElixirM1.TabIndex = 63;
            this.ElixirM1.Value = new decimal(new int[] {
            36,
            0,
            0,
            65536});
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.SpringGreen;
            this.label40.Location = new System.Drawing.Point(41, 422);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(100, 16);
            this.label40.TabIndex = 62;
            this.label40.Text = "Elixir Promedio:";
            // 
            // CalcularVidaM1
            // 
            this.CalcularVidaM1.AutoSize = true;
            this.CalcularVidaM1.BackColor = System.Drawing.Color.SpringGreen;
            this.CalcularVidaM1.Location = new System.Drawing.Point(172, 389);
            this.CalcularVidaM1.Name = "CalcularVidaM1";
            this.CalcularVidaM1.Size = new System.Drawing.Size(88, 16);
            this.CalcularVidaM1.TabIndex = 61;
            this.CalcularVidaM1.Text = "Puntos Vida...";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.SpringGreen;
            this.label42.Location = new System.Drawing.Point(41, 389);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(101, 16);
            this.label42.TabIndex = 60;
            this.label42.Text = "Puntos de Vida:";
            // 
            // CalcularDanoM1
            // 
            this.CalcularDanoM1.AutoSize = true;
            this.CalcularDanoM1.BackColor = System.Drawing.Color.SpringGreen;
            this.CalcularDanoM1.Location = new System.Drawing.Point(172, 359);
            this.CalcularDanoM1.Name = "CalcularDanoM1";
            this.CalcularDanoM1.Size = new System.Drawing.Size(91, 16);
            this.CalcularDanoM1.TabIndex = 59;
            this.CalcularDanoM1.Text = "Puntos daño...";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.SpringGreen;
            this.label44.Location = new System.Drawing.Point(41, 359);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(106, 16);
            this.label44.TabIndex = 58;
            this.label44.Text = "Puntos de Daño:";
            // 
            // M1
            // 
            this.M1.AutoSize = true;
            this.M1.BackColor = System.Drawing.Color.Chartreuse;
            this.M1.Font = new System.Drawing.Font("PanRoman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.M1.Location = new System.Drawing.Point(41, 327);
            this.M1.Name = "M1";
            this.M1.Size = new System.Drawing.Size(282, 18);
            this.M1.TabIndex = 57;
            this.M1.Text = "Archer Queen Princess bridge spam";
            // 
            // OponenteDesignado
            // 
            this.OponenteDesignado.AutoSize = true;
            this.OponenteDesignado.BackColor = System.Drawing.Color.Aqua;
            this.OponenteDesignado.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OponenteDesignado.Location = new System.Drawing.Point(647, 160);
            this.OponenteDesignado.Name = "OponenteDesignado";
            this.OponenteDesignado.Size = new System.Drawing.Size(159, 30);
            this.OponenteDesignado.TabIndex = 12;
            this.OponenteDesignado.Text = "Su Oponente es...";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Crimson;
            this.label4.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(647, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 18);
            this.label4.TabIndex = 11;
            this.label4.Text = "Oponente Designado:";
            // 
            // Nota
            // 
            this.Nota.AutoSize = true;
            this.Nota.BackColor = System.Drawing.Color.Crimson;
            this.Nota.Location = new System.Drawing.Point(85, 160);
            this.Nota.Name = "Nota";
            this.Nota.Size = new System.Drawing.Size(181, 16);
            this.Nota.TabIndex = 10;
            this.Nota.Tag = "";
            this.Nota.Text = "*Escribe tu nombre todo junto";
            // 
            // ObtenerUser
            // 
            this.ObtenerUser.BackColor = System.Drawing.Color.DeepPink;
            this.ObtenerUser.Location = new System.Drawing.Point(287, 132);
            this.ObtenerUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ObtenerUser.Name = "ObtenerUser";
            this.ObtenerUser.Size = new System.Drawing.Size(117, 41);
            this.ObtenerUser.TabIndex = 9;
            this.ObtenerUser.Text = "Registrarse";
            this.ObtenerUser.UseVisualStyleBackColor = false;
            this.ObtenerUser.Click += new System.EventHandler(this.ObtenerUser_Click);
            // 
            // UsuarioDesignado
            // 
            this.UsuarioDesignado.AutoSize = true;
            this.UsuarioDesignado.BackColor = System.Drawing.Color.Aqua;
            this.UsuarioDesignado.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsuarioDesignado.Location = new System.Drawing.Point(475, 160);
            this.UsuarioDesignado.Name = "UsuarioDesignado";
            this.UsuarioDesignado.Size = new System.Drawing.Size(137, 30);
            this.UsuarioDesignado.TabIndex = 8;
            this.UsuarioDesignado.Text = "Mi usuario es...";
            // 
            // ElejirEquipo
            // 
            this.ElejirEquipo.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ElejirEquipo.FormattingEnabled = true;
            this.ElejirEquipo.Items.AddRange(new object[] {
            "Team Queso",
            "Golden Wing"});
            this.ElejirEquipo.Location = new System.Drawing.Point(89, 108);
            this.ElejirEquipo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ElejirEquipo.Name = "ElejirEquipo";
            this.ElejirEquipo.Size = new System.Drawing.Size(171, 24);
            this.ElejirEquipo.TabIndex = 7;
            // 
            // EscribirNombre
            // 
            this.EscribirNombre.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.EscribirNombre.Location = new System.Drawing.Point(89, 178);
            this.EscribirNombre.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EscribirNombre.Name = "EscribirNombre";
            this.EscribirNombre.Size = new System.Drawing.Size(171, 22);
            this.EscribirNombre.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Crimson;
            this.label3.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(473, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Usuario Designado:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Crimson;
            this.label2.Location = new System.Drawing.Point(85, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nombre jugador:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Crimson;
            this.label1.Location = new System.Drawing.Point(85, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nombre del equipo:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkMagenta;
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.EmpezarP);
            this.tabPage2.Controls.Add(this.EscogerM4);
            this.tabPage2.Controls.Add(this.EscogerM2);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.BalanceM4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.Jugador2Print);
            this.tabPage2.Controls.Add(this.SinergiaM4);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.ElixirM4);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.CalcularVidaM4);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.CalcularDanoM4);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.M4);
            this.tabPage2.Controls.Add(this.DefensaM3);
            this.tabPage2.Controls.Add(this.BalanceM2);
            this.tabPage2.Controls.Add(this.SinergiaM2);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.ElixirM2);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.CalcularVidaM2);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.CalcularDanoM2);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.M2);
            this.tabPage2.Controls.Add(this.PicM4);
            this.tabPage2.Controls.Add(this.PicM2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(911, 682);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Elección de Mazos";
            // 
            // EmpezarP
            // 
            this.EmpezarP.BackColor = System.Drawing.Color.Lime;
            this.EmpezarP.Location = new System.Drawing.Point(442, 453);
            this.EmpezarP.Name = "EmpezarP";
            this.EmpezarP.Size = new System.Drawing.Size(109, 36);
            this.EmpezarP.TabIndex = 85;
            this.EmpezarP.Text = "Ver Resultado";
            this.EmpezarP.UseVisualStyleBackColor = false;
            this.EmpezarP.Click += new System.EventHandler(this.EmpezarP_Click);
            // 
            // EscogerM4
            // 
            this.EscogerM4.AutoSize = true;
            this.EscogerM4.BackColor = System.Drawing.Color.Crimson;
            this.EscogerM4.Location = new System.Drawing.Point(763, 188);
            this.EscogerM4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EscogerM4.Name = "EscogerM4";
            this.EscogerM4.Size = new System.Drawing.Size(46, 20);
            this.EscogerM4.TabIndex = 84;
            this.EscogerM4.TabStop = true;
            this.EscogerM4.Text = "M4";
            this.EscogerM4.UseVisualStyleBackColor = false;
            this.EscogerM4.CheckedChanged += new System.EventHandler(this.EscogerM4_CheckedChanged);
            // 
            // EscogerM2
            // 
            this.EscogerM2.AutoSize = true;
            this.EscogerM2.BackColor = System.Drawing.Color.Crimson;
            this.EscogerM2.Location = new System.Drawing.Point(357, 188);
            this.EscogerM2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EscogerM2.Name = "EscogerM2";
            this.EscogerM2.Size = new System.Drawing.Size(46, 20);
            this.EscogerM2.TabIndex = 83;
            this.EscogerM2.TabStop = true;
            this.EscogerM2.Text = "M2";
            this.EscogerM2.UseVisualStyleBackColor = false;
            this.EscogerM2.CheckedChanged += new System.EventHandler(this.EscogerM3_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.HotPink;
            this.label6.Font = new System.Drawing.Font("Segoe Script", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(67, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(363, 38);
            this.label6.TabIndex = 82;
            this.label6.Text = "Escoge el mazo del oponente";
            // 
            // BalanceM4
            // 
            this.BalanceM4.BackColor = System.Drawing.Color.DeepPink;
            this.BalanceM4.Enabled = false;
            this.BalanceM4.Location = new System.Drawing.Point(763, 378);
            this.BalanceM4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BalanceM4.Name = "BalanceM4";
            this.BalanceM4.Size = new System.Drawing.Size(61, 22);
            this.BalanceM4.TabIndex = 56;
            this.BalanceM4.Value = new decimal(new int[] {
            95,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(760, 359);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 55;
            this.label5.Text = "Balance:";
            // 
            // Jugador2Print
            // 
            this.Jugador2Print.AutoSize = true;
            this.Jugador2Print.BackColor = System.Drawing.Color.SeaGreen;
            this.Jugador2Print.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Jugador2Print.Location = new System.Drawing.Point(176, 98);
            this.Jugador2Print.Name = "Jugador2Print";
            this.Jugador2Print.Size = new System.Drawing.Size(43, 24);
            this.Jugador2Print.TabIndex = 54;
            this.Jugador2Print.Text = "J2...";
            // 
            // SinergiaM4
            // 
            this.SinergiaM4.BackColor = System.Drawing.Color.DeepPink;
            this.SinergiaM4.Enabled = false;
            this.SinergiaM4.Location = new System.Drawing.Point(763, 284);
            this.SinergiaM4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SinergiaM4.Name = "SinergiaM4";
            this.SinergiaM4.Size = new System.Drawing.Size(61, 22);
            this.SinergiaM4.TabIndex = 46;
            this.SinergiaM4.Value = new decimal(new int[] {
            65,
            0,
            0,
            0});
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(760, 265);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 16);
            this.label15.TabIndex = 44;
            this.label15.Text = "Sinergia:";
            // 
            // ElixirM4
            // 
            this.ElixirM4.BackColor = System.Drawing.Color.DeepPink;
            this.ElixirM4.DecimalPlaces = 1;
            this.ElixirM4.Enabled = false;
            this.ElixirM4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ElixirM4.Location = new System.Drawing.Point(628, 223);
            this.ElixirM4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ElixirM4.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ElixirM4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ElixirM4.Name = "ElixirM4";
            this.ElixirM4.Size = new System.Drawing.Size(61, 22);
            this.ElixirM4.TabIndex = 42;
            this.ElixirM4.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.RoyalBlue;
            this.label17.Location = new System.Drawing.Point(493, 223);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 16);
            this.label17.TabIndex = 41;
            this.label17.Text = "Elixir Promedio:";
            // 
            // CalcularVidaM4
            // 
            this.CalcularVidaM4.AutoSize = true;
            this.CalcularVidaM4.BackColor = System.Drawing.Color.DeepPink;
            this.CalcularVidaM4.Location = new System.Drawing.Point(625, 190);
            this.CalcularVidaM4.Name = "CalcularVidaM4";
            this.CalcularVidaM4.Size = new System.Drawing.Size(88, 16);
            this.CalcularVidaM4.TabIndex = 40;
            this.CalcularVidaM4.Text = "Puntos Vida...";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.RoyalBlue;
            this.label19.Location = new System.Drawing.Point(493, 190);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 16);
            this.label19.TabIndex = 39;
            this.label19.Text = "Puntos de Vida:";
            // 
            // CalcularDanoM4
            // 
            this.CalcularDanoM4.AutoSize = true;
            this.CalcularDanoM4.BackColor = System.Drawing.Color.DeepPink;
            this.CalcularDanoM4.Location = new System.Drawing.Point(625, 161);
            this.CalcularDanoM4.Name = "CalcularDanoM4";
            this.CalcularDanoM4.Size = new System.Drawing.Size(91, 16);
            this.CalcularDanoM4.TabIndex = 38;
            this.CalcularDanoM4.Text = "Puntos daño...";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.RoyalBlue;
            this.label21.Location = new System.Drawing.Point(493, 161);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(106, 16);
            this.label21.TabIndex = 37;
            this.label21.Text = "Puntos de Daño:";
            // 
            // M4
            // 
            this.M4.AutoSize = true;
            this.M4.BackColor = System.Drawing.Color.Aqua;
            this.M4.Font = new System.Drawing.Font("PanRoman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.M4.Location = new System.Drawing.Point(493, 133);
            this.M4.Name = "M4";
            this.M4.Size = new System.Drawing.Size(303, 18);
            this.M4.TabIndex = 36;
            this.M4.Text = "Ram Rage Mega Knight Archer Queen";
            // 
            // DefensaM3
            // 
            this.DefensaM3.Enabled = false;
            this.DefensaM3.Location = new System.Drawing.Point(331, 679);
            this.DefensaM3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DefensaM3.Name = "DefensaM3";
            this.DefensaM3.Size = new System.Drawing.Size(61, 22);
            this.DefensaM3.TabIndex = 35;
            this.DefensaM3.Value = new decimal(new int[] {
            95,
            0,
            0,
            0});
            // 
            // BalanceM2
            // 
            this.BalanceM2.BackColor = System.Drawing.Color.DeepPink;
            this.BalanceM2.Enabled = false;
            this.BalanceM2.Location = new System.Drawing.Point(357, 367);
            this.BalanceM2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BalanceM2.Name = "BalanceM2";
            this.BalanceM2.Size = new System.Drawing.Size(61, 22);
            this.BalanceM2.TabIndex = 23;
            this.BalanceM2.Value = new decimal(new int[] {
            91,
            0,
            0,
            0});
            // 
            // SinergiaM2
            // 
            this.SinergiaM2.BackColor = System.Drawing.Color.DeepPink;
            this.SinergiaM2.Enabled = false;
            this.SinergiaM2.Location = new System.Drawing.Point(357, 284);
            this.SinergiaM2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SinergiaM2.Name = "SinergiaM2";
            this.SinergiaM2.Size = new System.Drawing.Size(61, 22);
            this.SinergiaM2.TabIndex = 22;
            this.SinergiaM2.Value = new decimal(new int[] {
            83,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(355, 348);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Balance:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(355, 265);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Sinergia:";
            // 
            // ElixirM2
            // 
            this.ElixirM2.BackColor = System.Drawing.Color.DeepPink;
            this.ElixirM2.DecimalPlaces = 1;
            this.ElixirM2.Enabled = false;
            this.ElixirM2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ElixirM2.Location = new System.Drawing.Point(216, 234);
            this.ElixirM2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ElixirM2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ElixirM2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ElixirM2.Name = "ElixirM2";
            this.ElixirM2.Size = new System.Drawing.Size(61, 22);
            this.ElixirM2.TabIndex = 18;
            this.ElixirM2.Value = new decimal(new int[] {
            35,
            0,
            0,
            65536});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.RoyalBlue;
            this.label12.Location = new System.Drawing.Point(83, 234);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 16);
            this.label12.TabIndex = 17;
            this.label12.Text = "Elixir Promedio:";
            // 
            // CalcularVidaM2
            // 
            this.CalcularVidaM2.AutoSize = true;
            this.CalcularVidaM2.BackColor = System.Drawing.Color.DeepPink;
            this.CalcularVidaM2.Location = new System.Drawing.Point(213, 201);
            this.CalcularVidaM2.Name = "CalcularVidaM2";
            this.CalcularVidaM2.Size = new System.Drawing.Size(88, 16);
            this.CalcularVidaM2.TabIndex = 16;
            this.CalcularVidaM2.Text = "Puntos Vida...";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.RoyalBlue;
            this.label14.Location = new System.Drawing.Point(83, 201);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 16);
            this.label14.TabIndex = 15;
            this.label14.Text = "Puntos de Vida:";
            // 
            // CalcularDanoM2
            // 
            this.CalcularDanoM2.AutoSize = true;
            this.CalcularDanoM2.BackColor = System.Drawing.Color.DeepPink;
            this.CalcularDanoM2.Location = new System.Drawing.Point(213, 172);
            this.CalcularDanoM2.Name = "CalcularDanoM2";
            this.CalcularDanoM2.Size = new System.Drawing.Size(91, 16);
            this.CalcularDanoM2.TabIndex = 14;
            this.CalcularDanoM2.Text = "Puntos daño...";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.RoyalBlue;
            this.label16.Location = new System.Drawing.Point(83, 172);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 16);
            this.label16.TabIndex = 13;
            this.label16.Text = "Puntos de Daño:";
            // 
            // M2
            // 
            this.M2.AutoSize = true;
            this.M2.BackColor = System.Drawing.Color.Aqua;
            this.M2.Font = new System.Drawing.Font("PanRoman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.M2.Location = new System.Drawing.Point(83, 143);
            this.M2.Name = "M2";
            this.M2.Size = new System.Drawing.Size(297, 18);
            this.M2.TabIndex = 12;
            this.M2.Text = "Giant NW Bandit InfernoD beatdown";
            // 
            // PicM4
            // 
            this.PicM4.Image = global::Proyecto_Final_IP.Properties.Resources.mazo_4;
            this.PicM4.Location = new System.Drawing.Point(483, 265);
            this.PicM4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PicM4.Name = "PicM4";
            this.PicM4.Size = new System.Drawing.Size(233, 145);
            this.PicM4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicM4.TabIndex = 51;
            this.PicM4.TabStop = false;
            // 
            // PicM2
            // 
            this.PicM2.Image = ((System.Drawing.Image)(resources.GetObject("PicM2.Image")));
            this.PicM2.Location = new System.Drawing.Point(71, 265);
            this.PicM2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PicM2.Name = "PicM2";
            this.PicM2.Size = new System.Drawing.Size(233, 145);
            this.PicM2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicM2.TabIndex = 49;
            this.PicM2.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkMagenta;
            this.tabPage3.Controls.Add(this.BInicio);
            this.tabPage3.Controls.Add(this.IrACambiar);
            this.tabPage3.Controls.Add(this.MJ2);
            this.tabPage3.Controls.Add(this.MJ1);
            this.tabPage3.Controls.Add(this.J2);
            this.tabPage3.Controls.Add(this.PS1);
            this.tabPage3.Controls.Add(this.PS0);
            this.tabPage3.Controls.Add(this.ElixirJ2);
            this.tabPage3.Controls.Add(this.BalanceJ1);
            this.tabPage3.Controls.Add(this.ElixirJ1);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.BalanceJ2);
            this.tabPage3.Controls.Add(this.SinergiaJ2);
            this.tabPage3.Controls.Add(this.VidaJ2);
            this.tabPage3.Controls.Add(this.DanoJ2);
            this.tabPage3.Controls.Add(this.SinergiaJ1);
            this.tabPage3.Controls.Add(this.VidaJ1);
            this.tabPage3.Controls.Add(this.DanoJ1);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.MazoGanador);
            this.tabPage3.Controls.Add(this.J1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Size = new System.Drawing.Size(911, 682);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Resultados";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // BInicio
            // 
            this.BInicio.BackColor = System.Drawing.Color.Lime;
            this.BInicio.Location = new System.Drawing.Point(292, 424);
            this.BInicio.Name = "BInicio";
            this.BInicio.Size = new System.Drawing.Size(94, 32);
            this.BInicio.TabIndex = 34;
            this.BInicio.Text = "Inicio";
            this.BInicio.UseVisualStyleBackColor = false;
            this.BInicio.Click += new System.EventHandler(this.BInicio_Click);
            // 
            // IrACambiar
            // 
            this.IrACambiar.BackColor = System.Drawing.Color.Lime;
            this.IrACambiar.Location = new System.Drawing.Point(403, 424);
            this.IrACambiar.Name = "IrACambiar";
            this.IrACambiar.Size = new System.Drawing.Size(133, 32);
            this.IrACambiar.TabIndex = 33;
            this.IrACambiar.Text = "Cambiar Carta";
            this.IrACambiar.UseVisualStyleBackColor = false;
            this.IrACambiar.Click += new System.EventHandler(this.IrACambiar_Click);
            // 
            // MJ2
            // 
            this.MJ2.AutoSize = true;
            this.MJ2.BackColor = System.Drawing.Color.GreenYellow;
            this.MJ2.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MJ2.Location = new System.Drawing.Point(438, 90);
            this.MJ2.Name = "MJ2";
            this.MJ2.Size = new System.Drawing.Size(101, 22);
            this.MJ2.TabIndex = 32;
            this.MJ2.Text = "Mazo J2...";
            // 
            // MJ1
            // 
            this.MJ1.AutoSize = true;
            this.MJ1.BackColor = System.Drawing.Color.GreenYellow;
            this.MJ1.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MJ1.Location = new System.Drawing.Point(66, 90);
            this.MJ1.Name = "MJ1";
            this.MJ1.Size = new System.Drawing.Size(97, 22);
            this.MJ1.TabIndex = 31;
            this.MJ1.Text = "Mazo J1...";
            // 
            // J2
            // 
            this.J2.AutoSize = true;
            this.J2.BackColor = System.Drawing.Color.RosyBrown;
            this.J2.Font = new System.Drawing.Font("Pristina", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J2.Location = new System.Drawing.Point(433, 42);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(64, 37);
            this.J2.TabIndex = 30;
            this.J2.Text = "J2...";
            // 
            // PS1
            // 
            this.PS1.AutoSize = true;
            this.PS1.BackColor = System.Drawing.Color.Khaki;
            this.PS1.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PS1.Location = new System.Drawing.Point(436, 124);
            this.PS1.Name = "PS1";
            this.PS1.Size = new System.Drawing.Size(144, 17);
            this.PS1.TabIndex = 29;
            this.PS1.Text = "¿Ganador? ¿Perdedor?";
            // 
            // PS0
            // 
            this.PS0.AutoSize = true;
            this.PS0.BackColor = System.Drawing.Color.Khaki;
            this.PS0.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PS0.Location = new System.Drawing.Point(64, 124);
            this.PS0.Name = "PS0";
            this.PS0.Size = new System.Drawing.Size(144, 17);
            this.PS0.TabIndex = 28;
            this.PS0.Text = "¿Ganador? ¿Perdedor?";
            // 
            // ElixirJ2
            // 
            this.ElixirJ2.AutoSize = true;
            this.ElixirJ2.BackColor = System.Drawing.Color.Coral;
            this.ElixirJ2.Location = new System.Drawing.Point(564, 370);
            this.ElixirJ2.Name = "ElixirJ2";
            this.ElixirJ2.Size = new System.Drawing.Size(79, 16);
            this.ElixirJ2.TabIndex = 26;
            this.ElixirJ2.Text = "Elixir Prom...";
            // 
            // BalanceJ1
            // 
            this.BalanceJ1.AutoSize = true;
            this.BalanceJ1.BackColor = System.Drawing.Color.Coral;
            this.BalanceJ1.Location = new System.Drawing.Point(197, 327);
            this.BalanceJ1.Name = "BalanceJ1";
            this.BalanceJ1.Size = new System.Drawing.Size(66, 16);
            this.BalanceJ1.TabIndex = 25;
            this.BalanceJ1.Text = "Balance...";
            // 
            // ElixirJ1
            // 
            this.ElixirJ1.AutoSize = true;
            this.ElixirJ1.BackColor = System.Drawing.Color.Coral;
            this.ElixirJ1.Location = new System.Drawing.Point(197, 370);
            this.ElixirJ1.Name = "ElixirJ1";
            this.ElixirJ1.Size = new System.Drawing.Size(79, 16);
            this.ElixirJ1.TabIndex = 23;
            this.ElixirJ1.Text = "Elixir Prom...";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label35.Location = new System.Drawing.Point(436, 370);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(100, 16);
            this.label35.TabIndex = 22;
            this.label35.Text = "Elixir Promedio:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label41.Location = new System.Drawing.Point(64, 370);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(100, 16);
            this.label41.TabIndex = 21;
            this.label41.Text = "Elixir Promedio:";
            // 
            // BalanceJ2
            // 
            this.BalanceJ2.AutoSize = true;
            this.BalanceJ2.BackColor = System.Drawing.Color.Coral;
            this.BalanceJ2.Location = new System.Drawing.Point(564, 327);
            this.BalanceJ2.Name = "BalanceJ2";
            this.BalanceJ2.Size = new System.Drawing.Size(66, 16);
            this.BalanceJ2.TabIndex = 20;
            this.BalanceJ2.Text = "Balance...";
            // 
            // SinergiaJ2
            // 
            this.SinergiaJ2.AutoSize = true;
            this.SinergiaJ2.BackColor = System.Drawing.Color.Coral;
            this.SinergiaJ2.Location = new System.Drawing.Point(564, 277);
            this.SinergiaJ2.Name = "SinergiaJ2";
            this.SinergiaJ2.Size = new System.Drawing.Size(66, 16);
            this.SinergiaJ2.TabIndex = 19;
            this.SinergiaJ2.Text = "Sinergia...";
            // 
            // VidaJ2
            // 
            this.VidaJ2.AutoSize = true;
            this.VidaJ2.BackColor = System.Drawing.Color.Coral;
            this.VidaJ2.Location = new System.Drawing.Point(564, 227);
            this.VidaJ2.Name = "VidaJ2";
            this.VidaJ2.Size = new System.Drawing.Size(107, 16);
            this.VidaJ2.TabIndex = 18;
            this.VidaJ2.Text = "Puntos de Vida...";
            // 
            // DanoJ2
            // 
            this.DanoJ2.AutoSize = true;
            this.DanoJ2.BackColor = System.Drawing.Color.Coral;
            this.DanoJ2.Location = new System.Drawing.Point(564, 177);
            this.DanoJ2.Name = "DanoJ2";
            this.DanoJ2.Size = new System.Drawing.Size(112, 16);
            this.DanoJ2.TabIndex = 17;
            this.DanoJ2.Text = "Puntos de Daño...";
            // 
            // SinergiaJ1
            // 
            this.SinergiaJ1.AutoSize = true;
            this.SinergiaJ1.BackColor = System.Drawing.Color.Coral;
            this.SinergiaJ1.Location = new System.Drawing.Point(197, 277);
            this.SinergiaJ1.Name = "SinergiaJ1";
            this.SinergiaJ1.Size = new System.Drawing.Size(66, 16);
            this.SinergiaJ1.TabIndex = 15;
            this.SinergiaJ1.Text = "Sinergia...";
            // 
            // VidaJ1
            // 
            this.VidaJ1.AutoSize = true;
            this.VidaJ1.BackColor = System.Drawing.Color.Coral;
            this.VidaJ1.Location = new System.Drawing.Point(197, 227);
            this.VidaJ1.Name = "VidaJ1";
            this.VidaJ1.Size = new System.Drawing.Size(107, 16);
            this.VidaJ1.TabIndex = 14;
            this.VidaJ1.Text = "Puntos de Vida...";
            // 
            // DanoJ1
            // 
            this.DanoJ1.AutoSize = true;
            this.DanoJ1.BackColor = System.Drawing.Color.Coral;
            this.DanoJ1.Location = new System.Drawing.Point(197, 177);
            this.DanoJ1.Name = "DanoJ1";
            this.DanoJ1.Size = new System.Drawing.Size(112, 16);
            this.DanoJ1.TabIndex = 13;
            this.DanoJ1.Text = "Puntos de Daño...";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label24.Location = new System.Drawing.Point(436, 327);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 16);
            this.label24.TabIndex = 12;
            this.label24.Text = "Balance:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label25.Location = new System.Drawing.Point(436, 277);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 16);
            this.label25.TabIndex = 11;
            this.label25.Text = "Sinergia";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label26.Location = new System.Drawing.Point(436, 227);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(101, 16);
            this.label26.TabIndex = 10;
            this.label26.Text = "Puntos de Vida:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label27.Location = new System.Drawing.Point(436, 177);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(106, 16);
            this.label27.TabIndex = 9;
            this.label27.Text = "Puntos de Daño:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label23.Location = new System.Drawing.Point(64, 327);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 16);
            this.label23.TabIndex = 8;
            this.label23.Text = "Balance:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label20.Location = new System.Drawing.Point(64, 277);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 16);
            this.label20.TabIndex = 7;
            this.label20.Text = "Sinergia";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label18.Location = new System.Drawing.Point(64, 227);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 16);
            this.label18.TabIndex = 6;
            this.label18.Text = "Puntos de Vida:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label13.Location = new System.Drawing.Point(64, 177);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 16);
            this.label13.TabIndex = 5;
            this.label13.Text = "Puntos de Daño:";
            // 
            // MazoGanador
            // 
            this.MazoGanador.AutoSize = true;
            this.MazoGanador.Location = new System.Drawing.Point(67, 157);
            this.MazoGanador.Name = "MazoGanador";
            this.MazoGanador.Size = new System.Drawing.Size(0, 16);
            this.MazoGanador.TabIndex = 3;
            this.MazoGanador.Click += new System.EventHandler(this.MazoVencedor_Click);
            // 
            // J1
            // 
            this.J1.AutoSize = true;
            this.J1.BackColor = System.Drawing.Color.RosyBrown;
            this.J1.Font = new System.Drawing.Font("Pristina", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J1.Location = new System.Drawing.Point(61, 42);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(59, 37);
            this.J1.TabIndex = 2;
            this.J1.Text = "J1...";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DarkMagenta;
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.label90);
            this.tabPage4.Controls.Add(this.NuevaCarta);
            this.tabPage4.Controls.Add(this.NuevoMazo);
            this.tabPage4.Controls.Add(this.CambioCarta);
            this.tabPage4.Controls.Add(this.label33);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.EmpezarNuevo);
            this.tabPage4.Controls.Add(this.pictureBox6);
            this.tabPage4.Controls.Add(this.label64);
            this.tabPage4.Controls.Add(this.label62);
            this.tabPage4.Controls.Add(this.label61);
            this.tabPage4.Controls.Add(this.label57);
            this.tabPage4.Controls.Add(this.label58);
            this.tabPage4.Controls.Add(this.label59);
            this.tabPage4.Controls.Add(this.label60);
            this.tabPage4.Controls.Add(this.label53);
            this.tabPage4.Controls.Add(this.label54);
            this.tabPage4.Controls.Add(this.label55);
            this.tabPage4.Controls.Add(this.label56);
            this.tabPage4.Controls.Add(this.pictureBox5);
            this.tabPage4.Controls.Add(this.label52);
            this.tabPage4.Controls.Add(this.label48);
            this.tabPage4.Controls.Add(this.label49);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.label51);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label47);
            this.tabPage4.Controls.Add(this.label46);
            this.tabPage4.Controls.Add(this.label43);
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.MazoACambiar);
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(911, 682);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Cambiar Carta";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label90.Font = new System.Drawing.Font("Footlight MT Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(31, 243);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(242, 57);
            this.label90.TabIndex = 139;
            this.label90.Text = "Es importante que recuerdes \r\nque mazo utilizaste para cambiar\r\ntu carta.";
            // 
            // NuevaCarta
            // 
            this.NuevaCarta.BackColor = System.Drawing.SystemColors.Info;
            this.NuevaCarta.FormattingEnabled = true;
            this.NuevaCarta.Items.AddRange(new object[] {
            "Dragon Infernal",
            "Bruja Madre"});
            this.NuevaCarta.Location = new System.Drawing.Point(625, 266);
            this.NuevaCarta.Name = "NuevaCarta";
            this.NuevaCarta.Size = new System.Drawing.Size(149, 24);
            this.NuevaCarta.TabIndex = 138;
            // 
            // NuevoMazo
            // 
            this.NuevoMazo.BackColor = System.Drawing.SystemColors.Info;
            this.NuevoMazo.FormattingEnabled = true;
            this.NuevoMazo.Items.AddRange(new object[] {
            "Mazo 1",
            "Mazo 3"});
            this.NuevoMazo.Location = new System.Drawing.Point(342, 266);
            this.NuevoMazo.Name = "NuevoMazo";
            this.NuevoMazo.Size = new System.Drawing.Size(112, 24);
            this.NuevoMazo.TabIndex = 137;
            // 
            // CambioCarta
            // 
            this.CambioCarta.BackColor = System.Drawing.SystemColors.Info;
            this.CambioCarta.FormattingEnabled = true;
            this.CambioCarta.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.CambioCarta.Location = new System.Drawing.Point(486, 266);
            this.CambioCarta.Name = "CambioCarta";
            this.CambioCarta.Size = new System.Drawing.Size(112, 24);
            this.CambioCarta.TabIndex = 136;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Crimson;
            this.label33.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(632, 244);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(111, 19);
            this.label33.TabIndex = 135;
            this.label33.Text = "Nueva elección";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Crimson;
            this.label22.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(482, 244);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(116, 19);
            this.label22.TabIndex = 134;
            this.label22.Text = "Carta a cambiar";
            // 
            // EmpezarNuevo
            // 
            this.EmpezarNuevo.BackColor = System.Drawing.Color.GreenYellow;
            this.EmpezarNuevo.Location = new System.Drawing.Point(387, 311);
            this.EmpezarNuevo.Name = "EmpezarNuevo";
            this.EmpezarNuevo.Size = new System.Drawing.Size(89, 44);
            this.EmpezarNuevo.TabIndex = 108;
            this.EmpezarNuevo.Text = "Cambiar";
            this.EmpezarNuevo.UseVisualStyleBackColor = false;
            this.EmpezarNuevo.Click += new System.EventHandler(this.EmpezarNuevo_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Proyecto_Final_IP.Properties.Resources.clash_royale_bruja_madre;
            this.pictureBox6.Location = new System.Drawing.Point(448, 59);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(260, 166);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 104;
            this.pictureBox6.TabStop = false;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Crimson;
            this.label64.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(481, 17);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(188, 39);
            this.label64.TabIndex = 103;
            this.label64.Text = "Bruja Madre";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.Crimson;
            this.label62.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(31, 100);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(113, 42);
            this.label62.TabIndex = 102;
            this.label62.Text = "Asegurate de tu \r\nmejor opción.";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label61.Font = new System.Drawing.Font("Footlight MT Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(30, 311);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(248, 57);
            this.label61.TabIndex = 101;
            this.label61.Text = "Solo podrás cambiar 1 \r\ncarta de tu mazo a cambio del \r\n\"Dragón Infernal\" y \"Bruj" +
    "a Madre\".";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label57.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(654, 581);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(24, 28);
            this.label57.TabIndex = 100;
            this.label57.Text = "8";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label58.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(589, 581);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(24, 28);
            this.label58.TabIndex = 99;
            this.label58.Text = "7";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label59.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(529, 581);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(24, 28);
            this.label59.TabIndex = 98;
            this.label59.Text = "6";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label60.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(466, 581);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(24, 28);
            this.label60.TabIndex = 97;
            this.label60.Text = "5";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label53.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(654, 384);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(24, 28);
            this.label53.TabIndex = 96;
            this.label53.Text = "4";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label54.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(589, 384);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(24, 28);
            this.label54.TabIndex = 95;
            this.label54.Text = "3";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label55.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(529, 384);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(24, 28);
            this.label55.TabIndex = 94;
            this.label55.Text = "2";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label56.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(466, 384);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(21, 28);
            this.label56.TabIndex = 93;
            this.label56.Text = "1";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(448, 414);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(249, 164);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 92;
            this.pictureBox5.TabStop = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.DeepPink;
            this.label52.Font = new System.Drawing.Font("Courier New", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(456, 622);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(229, 40);
            this.label52.TabIndex = 91;
            this.label52.Text = "Ejemplo de posiciones \r\nsi escogiste Mazo 3";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label48.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(359, 581);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(24, 28);
            this.label48.TabIndex = 90;
            this.label48.Text = "8";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label49.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(294, 581);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(24, 28);
            this.label49.TabIndex = 89;
            this.label49.Text = "7";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label50.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(234, 581);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(24, 28);
            this.label50.TabIndex = 88;
            this.label50.Text = "6";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label51.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(171, 581);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(24, 28);
            this.label51.TabIndex = 87;
            this.label51.Text = "5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(359, 384);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 28);
            this.label9.TabIndex = 86;
            this.label9.Text = "4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(294, 384);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 28);
            this.label8.TabIndex = 85;
            this.label8.Text = "3";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label47.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(234, 384);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(24, 28);
            this.label47.TabIndex = 83;
            this.label47.Text = "2";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label46.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(174, 384);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 28);
            this.label46.TabIndex = 82;
            this.label46.Text = "1";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.DeepPink;
            this.label43.Font = new System.Drawing.Font("Courier New", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(167, 622);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(229, 40);
            this.label43.TabIndex = 81;
            this.label43.Text = "Ejemplo de posiciones \r\nsi escogiste Mazo 1";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Image = global::Proyecto_Final_IP.Properties.Resources.mazo_1;
            this.pictureBox4.Location = new System.Drawing.Point(149, 414);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(250, 164);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 80;
            this.pictureBox4.TabStop = false;
            // 
            // MazoACambiar
            // 
            this.MazoACambiar.AutoSize = true;
            this.MazoACambiar.BackColor = System.Drawing.Color.Crimson;
            this.MazoACambiar.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MazoACambiar.Location = new System.Drawing.Point(343, 244);
            this.MazoACambiar.Name = "MazoACambiar";
            this.MazoACambiar.Size = new System.Drawing.Size(117, 19);
            this.MazoACambiar.TabIndex = 4;
            this.MazoACambiar.Text = "Mazo a cambiar";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyecto_Final_IP.Properties.Resources.descarga;
            this.pictureBox3.Location = new System.Drawing.Point(172, 59);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(260, 166);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Crimson;
            this.label29.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(187, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(235, 39);
            this.label29.TabIndex = 0;
            this.label29.Text = "Dragon Infernal";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkMagenta;
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.M2Cambio);
            this.tabPage5.Controls.Add(this.M1Cambio);
            this.tabPage5.Controls.Add(this.J2Cambio);
            this.tabPage5.Controls.Add(this.NuevaJ2);
            this.tabPage5.Controls.Add(this.NuevaJ1);
            this.tabPage5.Controls.Add(this.EJ2);
            this.tabPage5.Controls.Add(this.BJ1);
            this.tabPage5.Controls.Add(this.EJ1);
            this.tabPage5.Controls.Add(this.label71);
            this.tabPage5.Controls.Add(this.label72);
            this.tabPage5.Controls.Add(this.BJ2);
            this.tabPage5.Controls.Add(this.SJ2);
            this.tabPage5.Controls.Add(this.VJ2);
            this.tabPage5.Controls.Add(this.DJ2);
            this.tabPage5.Controls.Add(this.SJ1);
            this.tabPage5.Controls.Add(this.VJ1);
            this.tabPage5.Controls.Add(this.DJ1);
            this.tabPage5.Controls.Add(this.label80);
            this.tabPage5.Controls.Add(this.label81);
            this.tabPage5.Controls.Add(this.label82);
            this.tabPage5.Controls.Add(this.label83);
            this.tabPage5.Controls.Add(this.label84);
            this.tabPage5.Controls.Add(this.label85);
            this.tabPage5.Controls.Add(this.label86);
            this.tabPage5.Controls.Add(this.label87);
            this.tabPage5.Controls.Add(this.label88);
            this.tabPage5.Controls.Add(this.J1Cambio);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(911, 682);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Nuevos Resultados";
            // 
            // M2Cambio
            // 
            this.M2Cambio.AutoSize = true;
            this.M2Cambio.BackColor = System.Drawing.Color.LimeGreen;
            this.M2Cambio.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M2Cambio.Location = new System.Drawing.Point(522, 143);
            this.M2Cambio.Name = "M2Cambio";
            this.M2Cambio.Size = new System.Drawing.Size(101, 22);
            this.M2Cambio.TabIndex = 59;
            this.M2Cambio.Text = "Mazo J2...";
            // 
            // M1Cambio
            // 
            this.M1Cambio.AutoSize = true;
            this.M1Cambio.BackColor = System.Drawing.Color.LimeGreen;
            this.M1Cambio.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M1Cambio.Location = new System.Drawing.Point(143, 143);
            this.M1Cambio.Name = "M1Cambio";
            this.M1Cambio.Size = new System.Drawing.Size(97, 22);
            this.M1Cambio.TabIndex = 58;
            this.M1Cambio.Text = "Mazo J1...";
            // 
            // J2Cambio
            // 
            this.J2Cambio.AutoSize = true;
            this.J2Cambio.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.J2Cambio.Font = new System.Drawing.Font("Pristina", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J2Cambio.Location = new System.Drawing.Point(517, 95);
            this.J2Cambio.Name = "J2Cambio";
            this.J2Cambio.Size = new System.Drawing.Size(64, 37);
            this.J2Cambio.TabIndex = 57;
            this.J2Cambio.Text = "J2...";
            // 
            // NuevaJ2
            // 
            this.NuevaJ2.AutoSize = true;
            this.NuevaJ2.BackColor = System.Drawing.Color.Crimson;
            this.NuevaJ2.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NuevaJ2.Location = new System.Drawing.Point(520, 177);
            this.NuevaJ2.Name = "NuevaJ2";
            this.NuevaJ2.Size = new System.Drawing.Size(144, 17);
            this.NuevaJ2.TabIndex = 56;
            this.NuevaJ2.Text = "¿Ganador? ¿Perdedor?";
            // 
            // NuevaJ1
            // 
            this.NuevaJ1.AutoSize = true;
            this.NuevaJ1.BackColor = System.Drawing.Color.Crimson;
            this.NuevaJ1.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NuevaJ1.Location = new System.Drawing.Point(141, 177);
            this.NuevaJ1.Name = "NuevaJ1";
            this.NuevaJ1.Size = new System.Drawing.Size(144, 17);
            this.NuevaJ1.TabIndex = 55;
            this.NuevaJ1.Text = "¿Ganador? ¿Perdedor?";
            // 
            // EJ2
            // 
            this.EJ2.AutoSize = true;
            this.EJ2.BackColor = System.Drawing.Color.PaleGreen;
            this.EJ2.Location = new System.Drawing.Point(648, 423);
            this.EJ2.Name = "EJ2";
            this.EJ2.Size = new System.Drawing.Size(79, 16);
            this.EJ2.TabIndex = 54;
            this.EJ2.Text = "Elixir Prom...";
            // 
            // BJ1
            // 
            this.BJ1.AutoSize = true;
            this.BJ1.BackColor = System.Drawing.Color.PaleGreen;
            this.BJ1.Location = new System.Drawing.Point(274, 380);
            this.BJ1.Name = "BJ1";
            this.BJ1.Size = new System.Drawing.Size(66, 16);
            this.BJ1.TabIndex = 53;
            this.BJ1.Text = "Balance...";
            // 
            // EJ1
            // 
            this.EJ1.AutoSize = true;
            this.EJ1.BackColor = System.Drawing.Color.PaleGreen;
            this.EJ1.Location = new System.Drawing.Point(274, 423);
            this.EJ1.Name = "EJ1";
            this.EJ1.Size = new System.Drawing.Size(79, 16);
            this.EJ1.TabIndex = 52;
            this.EJ1.Text = "Elixir Prom...";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.PaleGreen;
            this.label71.Location = new System.Drawing.Point(520, 423);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(100, 16);
            this.label71.TabIndex = 51;
            this.label71.Text = "Elixir Promedio:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.PaleGreen;
            this.label72.Location = new System.Drawing.Point(141, 423);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(100, 16);
            this.label72.TabIndex = 50;
            this.label72.Text = "Elixir Promedio:";
            // 
            // BJ2
            // 
            this.BJ2.AutoSize = true;
            this.BJ2.BackColor = System.Drawing.Color.PaleGreen;
            this.BJ2.Location = new System.Drawing.Point(648, 380);
            this.BJ2.Name = "BJ2";
            this.BJ2.Size = new System.Drawing.Size(66, 16);
            this.BJ2.TabIndex = 49;
            this.BJ2.Text = "Balance...";
            // 
            // SJ2
            // 
            this.SJ2.AutoSize = true;
            this.SJ2.BackColor = System.Drawing.Color.PaleGreen;
            this.SJ2.Location = new System.Drawing.Point(648, 330);
            this.SJ2.Name = "SJ2";
            this.SJ2.Size = new System.Drawing.Size(66, 16);
            this.SJ2.TabIndex = 48;
            this.SJ2.Text = "Sinergia...";
            // 
            // VJ2
            // 
            this.VJ2.AutoSize = true;
            this.VJ2.BackColor = System.Drawing.Color.Aqua;
            this.VJ2.Location = new System.Drawing.Point(648, 280);
            this.VJ2.Name = "VJ2";
            this.VJ2.Size = new System.Drawing.Size(107, 16);
            this.VJ2.TabIndex = 47;
            this.VJ2.Text = "Puntos de Vida...";
            // 
            // DJ2
            // 
            this.DJ2.AutoSize = true;
            this.DJ2.BackColor = System.Drawing.Color.Aqua;
            this.DJ2.Location = new System.Drawing.Point(648, 230);
            this.DJ2.Name = "DJ2";
            this.DJ2.Size = new System.Drawing.Size(112, 16);
            this.DJ2.TabIndex = 46;
            this.DJ2.Text = "Puntos de Daño...";
            // 
            // SJ1
            // 
            this.SJ1.AutoSize = true;
            this.SJ1.BackColor = System.Drawing.Color.PaleGreen;
            this.SJ1.Location = new System.Drawing.Point(274, 330);
            this.SJ1.Name = "SJ1";
            this.SJ1.Size = new System.Drawing.Size(66, 16);
            this.SJ1.TabIndex = 45;
            this.SJ1.Text = "Sinergia...";
            // 
            // VJ1
            // 
            this.VJ1.AutoSize = true;
            this.VJ1.BackColor = System.Drawing.Color.Aqua;
            this.VJ1.Location = new System.Drawing.Point(274, 280);
            this.VJ1.Name = "VJ1";
            this.VJ1.Size = new System.Drawing.Size(107, 16);
            this.VJ1.TabIndex = 44;
            this.VJ1.Text = "Puntos de Vida...";
            // 
            // DJ1
            // 
            this.DJ1.AutoSize = true;
            this.DJ1.BackColor = System.Drawing.Color.Aqua;
            this.DJ1.Location = new System.Drawing.Point(274, 230);
            this.DJ1.Name = "DJ1";
            this.DJ1.Size = new System.Drawing.Size(112, 16);
            this.DJ1.TabIndex = 43;
            this.DJ1.Text = "Puntos de Daño...";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.BackColor = System.Drawing.Color.PaleGreen;
            this.label80.Location = new System.Drawing.Point(520, 380);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(60, 16);
            this.label80.TabIndex = 42;
            this.label80.Text = "Balance:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.PaleGreen;
            this.label81.Location = new System.Drawing.Point(520, 330);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(57, 16);
            this.label81.TabIndex = 41;
            this.label81.Text = "Sinergia";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.Aqua;
            this.label82.Location = new System.Drawing.Point(520, 280);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(101, 16);
            this.label82.TabIndex = 40;
            this.label82.Text = "Puntos de Vida:";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.Aqua;
            this.label83.Location = new System.Drawing.Point(520, 230);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(106, 16);
            this.label83.TabIndex = 39;
            this.label83.Text = "Puntos de Daño:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.Color.PaleGreen;
            this.label84.Location = new System.Drawing.Point(141, 380);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(60, 16);
            this.label84.TabIndex = 38;
            this.label84.Text = "Balance:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.BackColor = System.Drawing.Color.PaleGreen;
            this.label85.Location = new System.Drawing.Point(141, 330);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(57, 16);
            this.label85.TabIndex = 37;
            this.label85.Text = "Sinergia";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.Aqua;
            this.label86.Location = new System.Drawing.Point(141, 280);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(101, 16);
            this.label86.TabIndex = 36;
            this.label86.Text = "Puntos de Vida:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.Aqua;
            this.label87.Location = new System.Drawing.Point(141, 230);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(106, 16);
            this.label87.TabIndex = 35;
            this.label87.Text = "Puntos de Daño:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(144, 210);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(0, 16);
            this.label88.TabIndex = 34;
            // 
            // J1Cambio
            // 
            this.J1Cambio.AutoSize = true;
            this.J1Cambio.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.J1Cambio.Font = new System.Drawing.Font("Pristina", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J1Cambio.Location = new System.Drawing.Point(138, 95);
            this.J1Cambio.Name = "J1Cambio";
            this.J1Cambio.Size = new System.Drawing.Size(59, 37);
            this.J1Cambio.TabIndex = 33;
            this.J1Cambio.Text = "J1...";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(348, 453);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 36);
            this.button1.TabIndex = 86;
            this.button1.Text = "Inicio";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.GreenYellow;
            this.button2.Location = new System.Drawing.Point(523, 311);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 44);
            this.button2.TabIndex = 140;
            this.button2.Text = "Inicio";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.GreenYellow;
            this.button3.Location = new System.Drawing.Point(367, 489);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 44);
            this.button3.TabIndex = 141;
            this.button3.Text = "Inicio";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(976, 753);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DefensaM3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceM2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SinergiaM2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElixirM2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicM4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicM2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ComboBox ElejirEquipo;
        private System.Windows.Forms.TextBox EscribirNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ObtenerUser;
        private System.Windows.Forms.Label UsuarioDesignado;
        private System.Windows.Forms.Label Nota;
        private System.Windows.Forms.Label OponenteDesignado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown BalanceM2;
        private System.Windows.Forms.NumericUpDown SinergiaM2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown ElixirM2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label CalcularVidaM2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label CalcularDanoM2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label M2;
        private System.Windows.Forms.NumericUpDown SinergiaM4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown ElixirM4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label CalcularVidaM4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label CalcularDanoM4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label M4;
        private System.Windows.Forms.NumericUpDown DefensaM3;
        private System.Windows.Forms.PictureBox PicM4;
        private System.Windows.Forms.PictureBox PicM2;
        private System.Windows.Forms.Label Jugador2Print;
        private System.Windows.Forms.RadioButton EscogerM3;
        private System.Windows.Forms.RadioButton EscogerM1;
        private System.Windows.Forms.Label Jugador1Print;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.NumericUpDown BalanceM3;
        private System.Windows.Forms.NumericUpDown SinergiaM3;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown ElixirM3;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label CalcularVidaM3;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label CalcularDanoM3;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label M3;
        private System.Windows.Forms.NumericUpDown BalanceM1;
        private System.Windows.Forms.NumericUpDown SinergiaM1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.NumericUpDown ElixirM1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label CalcularVidaM1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label CalcularDanoM1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label M1;
        private System.Windows.Forms.RadioButton EscogerM4;
        private System.Windows.Forms.RadioButton EscogerM2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown BalanceM4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button AvanzarA2;
        private System.Windows.Forms.Button EmpezarP;
        private System.Windows.Forms.Label ElixirJ1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label BalanceJ2;
        private System.Windows.Forms.Label SinergiaJ2;
        private System.Windows.Forms.Label VidaJ2;
        private System.Windows.Forms.Label DanoJ2;
        private System.Windows.Forms.Label SinergiaJ1;
        private System.Windows.Forms.Label VidaJ1;
        private System.Windows.Forms.Label DanoJ1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label MazoGanador;
        private System.Windows.Forms.Label J1;
        private System.Windows.Forms.Label BalanceJ1;
        private System.Windows.Forms.Label ElixirJ2;
        private System.Windows.Forms.Label PS1;
        private System.Windows.Forms.Label PS0;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label MazoACambiar;
        private System.Windows.Forms.Label J2;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button EmpezarNuevo;
        private System.Windows.Forms.Label MJ2;
        private System.Windows.Forms.Label MJ1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox NuevaCarta;
        private System.Windows.Forms.ComboBox NuevoMazo;
        private System.Windows.Forms.ComboBox CambioCarta;
        private System.Windows.Forms.Button IrACambiar;
        private System.Windows.Forms.Label M2Cambio;
        private System.Windows.Forms.Label M1Cambio;
        private System.Windows.Forms.Label J2Cambio;
        private System.Windows.Forms.Label NuevaJ2;
        private System.Windows.Forms.Label NuevaJ1;
        private System.Windows.Forms.Label EJ2;
        private System.Windows.Forms.Label BJ1;
        private System.Windows.Forms.Label EJ1;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label BJ2;
        private System.Windows.Forms.Label SJ2;
        private System.Windows.Forms.Label VJ2;
        private System.Windows.Forms.Label DJ2;
        private System.Windows.Forms.Label SJ1;
        private System.Windows.Forms.Label VJ1;
        private System.Windows.Forms.Label DJ1;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label J1Cambio;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Button BInicio;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

