﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final_IP
{
    class Carta
    {
        public string nombre;
        public int puntosvida;
        public int puntosdano;
    }
}
