﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Final_IP
{
    public partial class Form1 : Form
    {
        Mazo mazo1 = new Mazo();
        Mazo mazo3 = new Mazo();
        Mazo mazo2 = new Mazo();
        Mazo mazo4 = new Mazo();

        //valores para m1
        int ataque_m1 = 100, defensa_m1 = 83, sinergia_m1 = 65, balance_m1 = 88;

        //valores para m3
        int ataque_m3 = 77, defensa_m3 = 90, sinergia_m3 = 69, balance_m3 = 100;

        //valores para m2
        int ataque_m2 = 68, defensa_m2 = 95, sinergia_m2 = 83, balance_m2 = 91;

        //valores para m4
        int ataque_m4 = 100, defensa_m4 = 100, sinergia_m4 = 65, balance_m4 = 95;

        //dano promedio
        int d_m1 = 0, d_m3 = 0, d_m2 = 0, d_m4 = 0;

        //vida promedio
        int v_m1 = 0, v_m3 = 0, v_m2 = 0, v_m4 = 0;

        //variables para el cambio
        int VidaP1, VidaP2, VidaP3, VidaP4, DanoP1, DanoP2, DanoP3, DanoP4;

        //VALIDAR DANO PROMEDIO DE LOS MAZOS
        public int Calcular_dM1()
        {
            return d_m1 = 270;
        }
        public int Calcular_dM3()
        {
            return d_m3 = (mazo3.Designar_dano() / 8) * (defensa_m3 / ataque_m3);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        public int Calcular_dM2()
        {
            return d_m2 = (mazo2.Designar_dano() / 8) * (defensa_m2 / ataque_m2);
        }
        public int Calcular_dM4()
        {
            return d_m4 = (mazo4.Designar_dano() / 8) * (defensa_m4 / ataque_m4);
        }
        //VALIDAR VIDA PROMEDIO DE LOS MAZOS
        public int Calcular_vM1()
        {
            return v_m1 = (mazo1.Designar_vida() / 8) * (sinergia_m1 + balance_m1);
        }
        public int Calcular_vM3()
        {
            return v_m3 = (mazo3.Designar_vida() / 8) * (sinergia_m3 + balance_m3);
        }
        public int Calcular_vM2()
        {
            return v_m2 = (mazo2.Designar_vida() / 8) * (sinergia_m2 + balance_m2);
        }
        public int Calcular_vM4()
        {
            return v_m4 = (mazo4.Designar_vida() / 8) * (sinergia_m4 + balance_m4);
        }
        public Form1()
        {
            InitializeComponent();           

            CrearMazos();
        }
        private void ObtenerUser_Click(object sender, EventArgs e)
        {
            /*se creara el nombre de usuario de la persona recordar que debe componerse de la siguiente manera
             * EX. "TQ-NombreJugador12"*/

            string equipo = ElejirEquipo.Text;
            string nombre_jugador = EscribirNombre.Text;
            int longitud = 0;

            string obtener_primera = equipo.Substring(0, 1);

            string equipo1 = "Queso";
            string extra1 = "Team";
            string equipo2 = "Wing";
            string extra2 = "Golden";

            if (ElejirEquipo.Text == "Team Queso")
            {
                string extraer1 = equipo1.Substring(0, 1);
                string juntar1 = obtener_primera + extraer1 + nombre_jugador;
                longitud = juntar1.Length;

                UsuarioDesignado.Text = juntar1 + longitud;
                Jugador1Print.Text = juntar1 + longitud;
                J1.Text = juntar1 + longitud;
                J1Cambio.Text = juntar1 + longitud;

            } else if (ElejirEquipo.Text == "Golden Wing")
            {
                string extraer2 = equipo2.Substring(0, 1);
                string juntar2 = obtener_primera + extraer2 + nombre_jugador;
                longitud = juntar2.Length;

                UsuarioDesignado.Text = juntar2 + longitud;
                Jugador1Print.Text = juntar2 + longitud;
                J1.Text = juntar2 + longitud;
                J1Cambio.Text = juntar2 + longitud;

            }
            if (ElejirEquipo.Text == "Team Queso")
            {
                string obtener_extra2 = extra2.Substring(0, 1);
                string extraer1 = equipo2.Substring(0, 1);
                string juntar1 = obtener_extra2 + extraer1 + "Player";
                longitud = juntar1.Length;

                OponenteDesignado.Text = juntar1 + longitud;
                Jugador2Print.Text = juntar1 + longitud;
                J2.Text = juntar1 + longitud;
                J2Cambio.Text = juntar1 + longitud;

            } else if (ElejirEquipo.Text == "Golden Wing")
            {
                string obtener_extra2 = extra1.Substring(0, 1);
                string extraer2 = equipo1.Substring(0, 1);
                string juntar2 = obtener_extra2 + extraer2 + "Player";
                longitud = juntar2.Length;

                OponenteDesignado.Text = juntar2 + longitud;
                Jugador2Print.Text = juntar2 + longitud;
                J2.Text= juntar2 + longitud;
                J2Cambio.Text = juntar2 + longitud;
            }
        }
        private void EscogerM1_CheckedChanged_1(object sender, EventArgs e)
        {
            CalcularDanoM1.Text = mazo1.Designar_dano().ToString();
            CalcularVidaM1.Text = mazo1.Designar_vida().ToString();
        }
        private void EscogerM2_CheckedChanged_2(object sender, EventArgs e)
        {
            CalcularDanoM3.Text = mazo3.Designar_dano().ToString();
            CalcularVidaM3.Text = mazo3.Designar_vida().ToString();
        }
        private void tabPage4_Click(object sender, EventArgs e)
        {

        }
        private void IrACambiar_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 3;
        }

        private void BInicio_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        //METODO PARA EL CAMBIO DE CARTA

        private void CambiarCarta(Mazo _mazo, int _carta, string nuevo_nombre, int nuevos_puntosvida, int nuevos_puntosdano) {
            /*
            string nuevo_nombre = "dragon_infernal";
            int nuevos_puntosvida = 1294;
            int nuevos_puntosdano = 36;
            */

            /*
             * string nuevo_nombre = "bruja_madre";
            int nuevos_puntosvida = 532;
            int nuevos_puntosdano = 133;
             */
            switch (_carta) {
                case 1: {
                        _mazo.carta1.nombre = nuevo_nombre;
                        _mazo.carta1.puntosvida = nuevos_puntosvida;
                        _mazo.carta1.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 2:
                    {
                        _mazo.carta2.nombre = nuevo_nombre;
                        _mazo.carta2.puntosvida = nuevos_puntosvida;
                        _mazo.carta2.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 3:
                    {
                        _mazo.carta3.nombre = nuevo_nombre;
                        _mazo.carta3.puntosvida = nuevos_puntosvida;
                        _mazo.carta3.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 4:
                    {
                        _mazo.carta4.nombre = nuevo_nombre;
                        _mazo.carta4.puntosvida = nuevos_puntosvida;
                        _mazo.carta4.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 5:
                    {
                        _mazo.carta5.nombre = nuevo_nombre;
                        _mazo.carta5.puntosvida = nuevos_puntosvida;
                        _mazo.carta5.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 6:
                    {
                        _mazo.carta6.nombre = nuevo_nombre;
                        _mazo.carta6.puntosvida = nuevos_puntosvida;
                        _mazo.carta6.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 7:
                    {
                        _mazo.carta7.nombre = nuevo_nombre;
                        _mazo.carta7.puntosvida = nuevos_puntosvida;
                        _mazo.carta7.puntosdano = nuevos_puntosdano;
                    }
                    break;

                case 8:
                    {
                        _mazo.carta8.nombre = nuevo_nombre;
                        _mazo.carta8.puntosvida = nuevos_puntosvida;
                        _mazo.carta8.puntosdano = nuevos_puntosdano;
                    }
                    break;
            }
        }
        private void EmpezarNuevo_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 4;
            int cambio = Convert.ToInt32(CambioCarta.Text);
            int ValC = 0;
            //METODO PARA CAMBIO DE CARTAS MAZO 1

            if (NuevoMazo.Text == "Mazo 1" && cambio == 1 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 1, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            
            if (NuevoMazo.Text == "Mazo 1" && cambio == 1 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 1, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 2 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 2, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 2 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 2, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 3 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 3, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 3 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 3, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 4 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 4, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 4 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 4, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 5 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 5, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 5 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 5, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 6 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 6, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 6 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 6, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 7 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 7, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 7 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 7, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 8 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo1, 8, "dragon_inf", 1294, 36);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 1" && cambio == 8 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo1, 8, "bruja_m", 532, 133);
                DJ1.Text = mazo1.Designar_dano().ToString();
                VJ1.Text = mazo1.Designar_vida().ToString();
                SJ1.Text = sinergia_m1.ToString();
                BJ1.Text = balance_m1.ToString();
                EJ1.Text = ElixirM1.Value.ToString();

                if (EscogerM1.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";

                    }
                }
                if (EscogerM1.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }

            //METODO PARA CAMBIO DE CARTAS MAZO 3

            if (NuevoMazo.Text == "Mazo 3" && cambio == 1 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 1, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 1 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 1, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 2 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 2, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 2 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 2, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 3 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 3, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 3 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 3, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 4 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 4, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 4 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 4, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 5 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 5, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 5 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 5, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 6 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 6, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 6 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 6, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 7 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 7, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 7 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 7, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 8 && NuevaCarta.Text == "Dragon Infernal")
            {
                CambiarCarta(mazo3, 8, "dragon_inf", 1294, 36);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
            if (NuevoMazo.Text == "Mazo 3" && cambio == 8 && NuevaCarta.Text == "Bruja Madre")
            {
                CambiarCarta(mazo3, 8, "bruja_m", 532, 133);
                DJ1.Text = mazo3.Designar_dano().ToString();
                VJ1.Text = mazo3.Designar_vida().ToString();
                SJ1.Text = sinergia_m3.ToString();
                BJ1.Text = balance_m3.ToString();
                EJ1.Text = ElixirM3.Value.ToString();

                if (EscogerM3.Checked == true && EscogerM2.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
                if (EscogerM3.Checked == true && EscogerM4.Checked == true)
                {
                    //estapa 1//
                    if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                    {
                        ValC++;
                    }
                    //etapa 2//
                    if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                    {
                        ValC++;
                    }
                    //etapa 3//
                    if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                    {
                        ValC++;
                    }
                    if (ValC > 1)
                    {
                        NuevaJ1.Text = "HAS GANADO";
                        NuevaJ2.Text = "HAS PERDIDO";
                    }
                    else
                    {
                        NuevaJ1.Text = "HAS PERDIDO";
                        NuevaJ2.Text = "HAS GANADO";
                    }
                }
            }
        }
        private void CrearMazos() {

            /** VALORES INICIALES MAZO 1 **/
            mazo1.carta1.nombre = "reina_arquera";
            mazo1.carta1.puntosdano = 225;
            mazo1.carta1.puntosvida = 1000;

            mazo1.carta2.nombre = "bandida";
            mazo1.carta2.puntosdano = 193;
            mazo1.carta2.puntosvida = 907;

            mazo1.carta3.nombre = "fantasma_real";
            mazo1.carta3.puntosdano = 261;
            mazo1.carta3.puntosvida = 1210;

            mazo1.carta4.nombre = "espiritu_s";
            mazo1.carta4.puntosdano = 110;
            mazo1.carta4.puntosvida = 231;

            mazo1.carta5.nombre = "arquero_magico";
            mazo1.carta5.puntosdano = 134;
            mazo1.carta5.puntosvida = 532;

            mazo1.carta6.nombre = "princesa";
            mazo1.carta6.puntosdano = 169;
            mazo1.carta6.puntosvida = 261;

            mazo1.carta7.nombre = "ariete_de_b";
            mazo1.carta7.puntosdano = 265;
            mazo1.carta7.puntosvida = 911;

            mazo1.carta8.nombre = "barbaros_e";
            mazo1.carta8.puntosdano = 284;
            mazo1.carta8.puntosvida = 1341;

            /** VALORES INICIALES MAZO 3 **/
            mazo3.carta1.nombre = "bandida";
            mazo3.carta1.puntosdano = 193;
            mazo3.carta1.puntosvida = 907;

            mazo3.carta2.nombre = "gigante";
            mazo3.carta2.puntosdano = 254;
            mazo3.carta2.puntosvida = 4091;

            mazo3.carta3.nombre = "dragon_i";
            mazo3.carta3.puntosdano = 36;
            mazo3.carta3.puntosvida = 1294;

            mazo3.carta4.nombre = "tronco";
            mazo3.carta4.puntosdano = 58;
            mazo3.carta4.puntosvida = 290;

            mazo3.carta5.nombre = "megaesbirro";
            mazo3.carta5.puntosdano = 311;
            mazo3.carta5.puntosvida = 837;

            mazo3.carta6.nombre = "bruja_noc";
            mazo3.carta6.puntosdano = 314;
            mazo3.carta6.puntosvida = 907;

            mazo3.carta7.nombre = "veneno";
            mazo3.carta7.puntosdano = 728;
            mazo3.carta7.puntosvida = 0;

            mazo3.carta8.nombre = "descarga";
            mazo3.carta8.puntosdano = 192;
            mazo3.carta8.puntosvida = 0;

            /** VALORES INICIALES MAZO 2 **/
            mazo2.carta1.nombre = "globo";
            mazo2.carta1.puntosdano = 640;
            mazo2.carta1.puntosvida = 1680;

            mazo2.carta2.nombre = "hielo";
            mazo2.carta2.puntosdano = 115;
            mazo2.carta2.puntosvida = 0;

            mazo2.carta3.nombre = "mago_d_hielo";
            mazo2.carta3.puntosdano = 90;
            mazo2.carta3.puntosvida = 688;

            mazo2.carta4.nombre = "lenador";
            mazo2.carta4.puntosdano = 242;
            mazo2.carta4.puntosvida = 1282;

            mazo2.carta5.nombre = "megaesbirro";
            mazo2.carta5.puntosdano = 311;
            mazo2.carta5.puntosvida = 837;

            mazo2.carta6.nombre = "tornado";
            mazo2.carta6.puntosdano = 169;
            mazo2.carta6.puntosvida = 0;

            mazo2.carta7.nombre = "valquiria";
            mazo2.carta7.puntosdano = 267;
            mazo2.carta7.puntosvida = 1908;

            mazo2.carta8.nombre = "descarga";
            mazo2.carta8.puntosdano = 192;
            mazo2.carta8.puntosvida = 0;

            /** VALORES INICIALES MAZO 4 **/
            mazo4.carta1.nombre = "reina_arquera";
            mazo4.carta1.puntosdano = 225;
            mazo4.carta1.puntosvida = 1000;

            mazo4.carta2.nombre = "bandida";
            mazo4.carta2.puntosdano = 193;
            mazo4.carta2.puntosvida = 907;

            mazo4.carta3.nombre = "espiritu_electrico";
            mazo4.carta3.puntosdano = 99;
            mazo4.carta3.puntosvida = 230;

            mazo4.carta4.nombre = "fantasma_real";
            mazo4.carta4.puntosdano = 261;
            mazo4.carta4.puntosvida = 1210;

            mazo4.carta5.nombre = "rayo";
            mazo4.carta5.puntosdano = 1056;
            mazo4.carta5.puntosvida = 0;

            mazo4.carta6.nombre = "megacabellero";
            mazo4.carta6.puntosdano = 268;
            mazo4.carta6.puntosvida = 3993;

            mazo4.carta7.nombre = "montacarneros";
            mazo4.carta7.puntosdano = 266;
            mazo4.carta7.puntosvida = 1767;

            mazo4.carta8.nombre = "bola_d_nieve";
            mazo4.carta8.puntosdano = 192;
            mazo4.carta8.puntosvida = 0;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }
        private void EscogerM3_CheckedChanged(object sender, EventArgs e)
        {
            CalcularDanoM2.Text = mazo2.Designar_dano().ToString();
            CalcularVidaM2.Text = mazo2.Designar_vida().ToString();
        }
        private void EscogerM4_CheckedChanged(object sender, EventArgs e)
        {
            CalcularDanoM4.Text = mazo4.Designar_dano().ToString();
            CalcularVidaM4.Text = mazo4.Designar_vida().ToString();
        }
        private void AvanzarA2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }
        private void EmpezarP_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;

            //boton que tiene como funcion determinar al mazo ganador entre los jugador despues

            VidaP1 = Calcular_vM1();
            VidaP2 = Calcular_vM2();
            VidaP3 = Calcular_vM3();
            VidaP4 = Calcular_vM4();
            DanoP1 = Calcular_dM1();
            DanoP2 = Calcular_vM2();
            DanoP3 = Calcular_vM3();
            DanoP4 = Calcular_vM4();
            int Val = 0;

            if (EscogerM1.Checked == true && EscogerM2.Checked == true)
            {
                //estapa 1//
                if (VidaP1 > DanoP2 && VidaP2 < DanoP1)
                {
                    Val++;
                }
                //etapa 2//
                if (DanoP1 > DanoP2 && (sinergia_m1 + balance_m1) > (sinergia_m2 + balance_m2))
                {
                    Val++;
                }
                //etapa 3//
                if (VidaP1 > VidaP2 && (ataque_m1 + defensa_m1) > (ataque_m2 + defensa_m2))
                {
                    Val++;
                }
                if (Val > 1)
                {
                    PS0.Text = "TU MAZO HA GANADO";
                    PS1.Text = "TU MAZO HA PERDIDO";

                    //m1 propiedades
                    MJ1.Text = M1.Text;
                    M1Cambio.Text = M1.Text;
                    DanoJ1.Text = CalcularDanoM1.Text;
                    VidaJ1.Text = CalcularVidaM1.Text;
                    SinergiaJ1.Text = sinergia_m1.ToString();
                    BalanceJ1.Text = balance_m1.ToString();
                    ElixirJ1.Text = ElixirM1.Value.ToString();

                    //m2 propiedades
                    MJ2.Text = M2.Text;
                    M2Cambio.Text = M2.Text;
                    DanoJ2.Text = CalcularDanoM2.Text;
                    VidaJ2.Text = CalcularVidaM2.Text;
                    SinergiaJ2.Text = sinergia_m2.ToString();
                    BalanceJ2.Text = balance_m2.ToString();
                    ElixirJ2.Text = ElixirM2.Value.ToString();

                    DJ2.Text = CalcularDanoM2.Text;
                    VJ2.Text = CalcularVidaM2.Text;
                    SJ2.Text = sinergia_m2.ToString();
                    BJ2.Text = balance_m2.ToString();
                    EJ2.Text = ElixirM2.Value.ToString();
                }
                else
                {
                    PS0.Text = "TU MAZO HA PERDIDO";
                    PS1.Text = "TU MAZO HA GANADO";

                    //ganador m2 propiedades
                    MJ2.Text = M2.Text;
                    M2Cambio.Text = M2.Text;
                    DanoJ2.Text = CalcularDanoM2.Text;
                    VidaJ2.Text = CalcularVidaM2.Text;
                    SinergiaJ2.Text = sinergia_m2.ToString();
                    BalanceJ2.Text = balance_m2.ToString();
                    ElixirJ2.Text = ElixirM2.Value.ToString();

                    DJ2.Text = CalcularDanoM2.Text;
                    VJ2.Text = CalcularVidaM2.Text;
                    SJ2.Text = sinergia_m2.ToString();
                    BJ2.Text = balance_m2.ToString();
                    EJ2.Text = ElixirM2.Value.ToString();

                    //m1 propiedades
                    MJ1.Text = M1.Text;
                    M1Cambio.Text = M1.Text;
                    DanoJ1.Text = CalcularDanoM1.Text;
                    VidaJ1.Text = CalcularVidaM1.Text;
                    SinergiaJ1.Text = sinergia_m1.ToString();
                    BalanceJ1.Text = balance_m1.ToString();
                    ElixirJ1.Text = ElixirM1.Value.ToString();
                }
            }
            if (EscogerM1.Checked == true && EscogerM4.Checked == true)
            {
                //estapa 1//
                if (VidaP1 > DanoP4 && VidaP4 < DanoP1)
                {
                    Val++;
                }
                //etapa 2//
                if (DanoP1 > DanoP4 && (sinergia_m1 + balance_m1) > (sinergia_m4 + balance_m4))
                {
                    Val++;
                }
                //etapa 3//
                if (VidaP1 > VidaP4 && (ataque_m1 + defensa_m1) > (ataque_m4 + defensa_m4))
                {
                    Val++;
                }
                if (Val > 1)
                {
                    PS0.Text = "TU MAZO HA GANADO";
                    PS1.Text = "TU MAZO HA PERDIDO";

                    //m1 propiedades
                    MJ1.Text = M1.Text;
                    M1Cambio.Text = M1.Text;
                    DanoJ1.Text = CalcularDanoM1.Text;
                    VidaJ1.Text = CalcularVidaM1.Text;
                    SinergiaJ1.Text = sinergia_m1.ToString();
                    BalanceJ1.Text = balance_m1.ToString();
                    ElixirJ1.Text = ElixirM1.Value.ToString();

                    //m4 propiedades
                    MJ2.Text = M4.Text;
                    M2Cambio.Text = M4.Text;
                    DanoJ2.Text = CalcularDanoM4.Text;
                    VidaJ2.Text = CalcularVidaM4.Text;
                    SinergiaJ2.Text = sinergia_m4.ToString();
                    BalanceJ2.Text = balance_m4.ToString();
                    ElixirJ2.Text = ElixirM4.Value.ToString();

                    DJ2.Text = CalcularDanoM4.Text;
                    VJ2.Text = CalcularVidaM4.Text;
                    SJ2.Text = sinergia_m4.ToString();
                    BJ2.Text = balance_m4.ToString();
                    EJ2.Text = ElixirM4.Value.ToString();
                }
                else
                {
                    PS0.Text = "TU MAZO HA PERDIDO";
                    PS1.Text = "TU MAZO HA GANADO";

                    //m4 propiedades
                    MJ2.Text = M4.Text;
                    M2Cambio.Text = M4.Text;
                    DanoJ2.Text = CalcularDanoM4.Text;
                    VidaJ2.Text = CalcularVidaM4.Text;
                    SinergiaJ2.Text = sinergia_m4.ToString();
                    BalanceJ2.Text = balance_m4.ToString();
                    ElixirJ2.Text = ElixirM4.Value.ToString();

                    DJ2.Text = CalcularDanoM4.Text;
                    VJ2.Text = CalcularVidaM4.Text;
                    SJ2.Text = sinergia_m4.ToString();
                    BJ2.Text = balance_m4.ToString();
                    EJ2.Text = ElixirM4.Value.ToString();

                    //m1 propiedades
                    MJ1.Text = M1.Text;
                    M1Cambio.Text = M1.Text;
                    DanoJ1.Text = CalcularDanoM1.Text;
                    VidaJ1.Text = CalcularVidaM1.Text;
                    SinergiaJ1.Text = sinergia_m1.ToString();
                    BalanceJ1.Text = balance_m1.ToString();
                    ElixirJ1.Text = ElixirM1.Value.ToString();
                }
            }
            if (EscogerM3.Checked == true && EscogerM2.Checked == true)
            {
                //estapa 1//
                if (VidaP3 > DanoP2 && VidaP2 < DanoP3)
                {
                    Val++;
                }
                //etapa 2//
                if (DanoP3 > DanoP2 && (sinergia_m3 + balance_m3) > (sinergia_m2 + balance_m2))
                {
                    Val++;
                }
                //etapa 3//
                if (VidaP3 > VidaP2 && (ataque_m3 + defensa_m3) > (ataque_m2 + defensa_m2))
                {
                    Val++;
                }
                if (Val > 1)
                {
                    PS0.Text = "TU MAZO HA GANADO";
                    PS1.Text = "TU MAZO HA PERDIDO";

                    //m3 propiedades
                    MJ1.Text = M3.Text;
                    M1Cambio.Text = M3.Text;
                    DanoJ1.Text = CalcularDanoM3.Text;
                    VidaJ1.Text = CalcularVidaM3.Text;
                    SinergiaJ1.Text = sinergia_m3.ToString();
                    BalanceJ1.Text = balance_m3.ToString();
                    ElixirJ1.Text = ElixirM3.Value.ToString();

                    //m2 propiedades
                    MJ2.Text = M2.Text;
                    M2Cambio.Text = M2.Text;
                    DanoJ2.Text = CalcularDanoM2.Text;
                    VidaJ2.Text = CalcularVidaM2.Text;
                    SinergiaJ2.Text = sinergia_m2.ToString();
                    BalanceJ2.Text = balance_m2.ToString();
                    ElixirJ2.Text = ElixirM2.Value.ToString();

                    DJ2.Text = CalcularDanoM2.Text;
                    VJ2.Text = CalcularVidaM2.Text;
                    SJ2.Text = sinergia_m2.ToString();
                    BJ2.Text = balance_m2.ToString();
                    EJ2.Text = ElixirM2.Value.ToString();
                }
                else
                {
                    PS0.Text = "TU MAZO HA PERDIDO";
                    PS1.Text = "TU MAZO HA GANADO";

                    //m2 propiedades
                    MJ2.Text = M2.Text;
                    M2Cambio.Text = M2.Text;
                    DanoJ2.Text = CalcularDanoM2.Text;
                    VidaJ2.Text = CalcularVidaM2.Text;
                    SinergiaJ2.Text = sinergia_m2.ToString();
                    BalanceJ2.Text = balance_m2.ToString();
                    ElixirJ2.Text = ElixirM2.Value.ToString();

                    DJ2.Text = CalcularDanoM2.Text;
                    VJ2.Text = CalcularVidaM2.Text;
                    SJ2.Text = sinergia_m2.ToString();
                    BJ2.Text = balance_m2.ToString();
                    EJ2.Text = ElixirM2.Value.ToString();

                    //m3 propiedades
                    MJ1.Text = M3.Text;
                    M1Cambio.Text = M3.Text;
                    DanoJ1.Text = CalcularDanoM3.Text;
                    VidaJ1.Text = CalcularVidaM3.Text;
                    SinergiaJ1.Text = sinergia_m3.ToString();
                    BalanceJ1.Text = balance_m3.ToString();
                    ElixirJ1.Text = ElixirM3.Value.ToString();
                }
            }
            if (EscogerM3.Checked == true && EscogerM4.Checked == true)
            {
                //estapa 1//
                if (VidaP3 > DanoP4 && VidaP4 < DanoP3)
                {
                    Val++;
                }
                //etapa 2//
                if (DanoP3 > DanoP4 && (sinergia_m3 + balance_m3) > (sinergia_m4 + balance_m4))
                {
                    Val++;
                }
                //etapa 3//
                if (VidaP3 > VidaP4 && (ataque_m3 + defensa_m3) > (ataque_m4 + defensa_m4))
                {
                    Val++;
                }
                if (Val > 1)
                {
                    PS0.Text = "TU MAZO HA GANADO";
                    PS1.Text = "TU MAZO HA PERDIDO";

                    //m3 propiedades
                    MJ1.Text = M3.Text;
                    M1Cambio.Text = M3.Text;
                    DanoJ1.Text = CalcularDanoM3.Text;
                    VidaJ1.Text = CalcularVidaM3.Text;
                    SinergiaJ1.Text = sinergia_m3.ToString();
                    BalanceJ1.Text = balance_m3.ToString();
                    ElixirJ1.Text = ElixirM3.Value.ToString();

                    //m4 propiedades
                    MJ2.Text = M4.Text;
                    M2Cambio.Text = M4.Text;
                    DanoJ2.Text = CalcularDanoM4.Text;
                    VidaJ2.Text = CalcularVidaM4.Text;
                    SinergiaJ2.Text = sinergia_m4.ToString();
                    BalanceJ2.Text = balance_m4.ToString();
                    ElixirJ2.Text = ElixirM4.Value.ToString();

                    DJ2.Text = CalcularDanoM4.Text;
                    VJ2.Text = CalcularVidaM4.Text;
                    SJ2.Text = sinergia_m4.ToString();
                    BJ2.Text = balance_m4.ToString();
                    EJ2.Text = ElixirM4.Value.ToString();
                }
                else
                {
                    PS0.Text = "TU MAZO HA PERDIDO";
                    PS1.Text = "TU MAZO HA GANADO";

                    //m4 propiedades
                    MJ2.Text = M4.Text;
                    M2Cambio.Text = M4.Text;
                    DanoJ2.Text = CalcularDanoM4.Text;
                    VidaJ2.Text = CalcularVidaM4.Text;
                    SinergiaJ2.Text = sinergia_m4.ToString();
                    BalanceJ2.Text = balance_m4.ToString();
                    ElixirJ2.Text = ElixirM4.Value.ToString();

                    DJ2.Text = CalcularDanoM4.Text;
                    VJ2.Text = CalcularVidaM4.Text;
                    SJ2.Text = sinergia_m4.ToString();
                    BJ2.Text = balance_m4.ToString();
                    EJ2.Text = ElixirM4.Value.ToString();

                    //m3 propiedades
                    MJ1.Text = M3.Text;
                    M1Cambio.Text = M3.Text;
                    DanoJ1.Text = CalcularDanoM3.Text;
                    VidaJ1.Text = CalcularVidaM3.Text;
                    SinergiaJ1.Text = sinergia_m3.ToString();
                    BalanceJ1.Text = balance_m3.ToString();
                    ElixirJ1.Text = ElixirM3.Value.ToString();
                }
            }
        }
            private void tabPage3_Click(object sender, EventArgs e)
            {

            }

        private void MazoVencedor_Click(object sender, EventArgs e)
        {

        }

        private void CambiarCar_Click(object sender, EventArgs e)
        {

        }
        private void label61_Click(object sender, EventArgs e)
        {

        }
    }
}