﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final_IP
{
    internal class Mazo
    {
        public Carta carta1 = new Carta();
        public Carta carta2 = new Carta();
        public Carta carta3 = new Carta();
        public Carta carta4 = new Carta();
        public Carta carta5 = new Carta();
        public Carta carta6 = new Carta();
        public Carta carta7 = new Carta();
        public Carta carta8 = new Carta();

        //para jugador principal
        public int calcular_dano = 0;
        public int calcular_vida = 0;
        public int Designar_dano()
        {
            calcular_dano = carta1.puntosdano + carta2.puntosdano + carta3.puntosdano + carta4.puntosdano + carta5.puntosdano + carta6.puntosdano + carta7.puntosdano + carta8.puntosdano;
            return this.calcular_dano;
        }
        public int Designar_vida()
        {
            calcular_vida = carta1.puntosvida + carta2.puntosvida + carta3.puntosvida + carta4.puntosvida + carta5.puntosvida + carta6.puntosvida + carta7.puntosvida + carta8.puntosvida;
            return this.calcular_vida;
        }

    }
}
