﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L8_1166322_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero");
            int numero = int.Parse(Console.ReadLine());

            while (numero > 18)
            {
                Console.WriteLine("Aun estas a salvo");
                Console.WriteLine("Ingresa otro numero");

                numero = int.Parse(Console.ReadLine());

                Console.WriteLine("Veamos...");
            }

            Console.WriteLine("Ya no estas a salvo");
            Console.ReadLine();

            do
            {
                Console.WriteLine("Este es el do-while");
            } while (numero > 18);
            Console.ReadLine();
        }
    }
}
