﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T6_EAPM_1166322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int otra;
            do
            {
                Console.WriteLine("Ingrese su dia de nacimiento");
                int dia = int.Parse(Console.ReadLine());

                Console.WriteLine("Ingrese su mes de nacimiento (¡¡PORFAVOR ESCRIBA EL MES EN MINUSCULAS!!)");
                String mes = Console.ReadLine();

                Console.WriteLine("Ingrese su año de nacimiento");
                int año = int.Parse(Console.ReadLine());

                if ((mes == "marzo" && dia >= 21) || (mes == "abril" && dia <= 19))
                {
                    Console.WriteLine("Al habe nacido el " + dia + " de " + mes + " del " + año + ", su signo es Aries");
                }
                else if ((mes == "abril" && dia >= 20) || (mes == "mayo" && dia <= 20))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Tauro");
                }
                else if ((mes == "mayo" && dia >= 21) || (mes == "junio" && dia <= 20))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Geminis");
                }
                else if ((mes == "junio" && dia >= 21) || (mes == "julio" && dia <= 22))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Cancer");
                }
                else if ((mes == "julio" && dia >= 23) || (mes == "agosto" && dia <= 22))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Leo");
                }
                else if ((mes == "agosto" && dia >= 23) || (mes == "septiembre" && dia <= 22))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Virgo");
                }
                else if ((mes == "septiembre" && dia >= 23) || (mes == "octubre" && dia <= 22))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Libra");
                }
                else if ((mes == "octubre" && dia >= 23) || (mes == "noviembre" && dia <= 21))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Escorpio");
                }
                else if ((mes == "noviembre" && dia >= 22) || (mes == "diciembre" && dia <= 21))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Sagitario");
                }
                else if ((mes == "diciembre" && dia >= 22) || (mes == "enero" && dia <= 19))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Capricornio");
                }
                else if ((mes == "enero" && dia >= 20) || (mes == "febrero" && dia <= 18))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Acuario");
                }
                else if ((mes == "febrero" && dia >= 19) || (mes == "marzo" && dia <= 20))
                {
                    Console.WriteLine("Al haber nacido el " + dia + " de " + mes + " del " + año + ", su signo es Piscis");
                }
                else
                {
                    Console.WriteLine("¡UPS! Parametros inválidos ingresados");
                }
            
                Console.WriteLine("¿Desea volver a ejecturar? Si es asi, presiones 1 sino presiones cualquier otra tecla");
                otra = int.Parse(Console.ReadLine());

            } while (otra==1);

        } 
       
    }

}
