﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp21
{
    internal class motocicleta
    {
        //atributos privados
        int modelo = 2019;
        double precio = 1000;
        string marca = "";
        double iva = 0.12;

        //metodos públicos

        public motocicleta(int modelo, double precio, string marca, double iva)
        {
            this.modelo = modelo;
            this.precio = precio;
            this.marca = marca; 
            this.iva = iva; 
        }
        public int MostrarModelo()
        {
            return this.modelo;

        }
        public double DefinirPrecio()
        {
            return this.precio;
        }
        public string MostrarMarca()
        {
            return this.marca;
        }
        public void DefinirIva(double iiva)
        {
            if(iiva > 0 && iiva < 1)
            {
                iva = iiva;
            }
            else
            {
                Console.WriteLine("Parametro Incorrecto");
            }
            
        }
        public double PrecioSinIva()
        {
            return this.precio;
        }
        public double AsignarIva()
        {
            return this.precio * iva;
        }
        public double CalcularIva()
        {
            return this.precio - AsignarIva();
        }
        public double PrecioConIva()
        {
            return this.precio + CalcularIva();
        }

    }
}
