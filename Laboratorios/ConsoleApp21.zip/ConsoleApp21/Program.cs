﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            motocicleta moto1 = new motocicleta(2022, 25000, "Honda", 3);
            Console.WriteLine("El modelo es: " + moto1.MostrarModelo());
            Console.WriteLine("El precio actual sin IVA es: " + moto1.PrecioSinIva());
            Console.WriteLine("El IVA de la compra es: " + moto1.CalcularIva());
            Console.WriteLine("El precio total de venta es: " + moto1.PrecioConIva());

            Console.ReadKey();
        }
    }
}
