﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.inputDatos = new System.Windows.Forms.Button();
            this.inputDescripcion = new System.Windows.Forms.RichTextBox();
            this.inputPrecio = new System.Windows.Forms.NumericUpDown();
            this.inputModelo = new System.Windows.Forms.NumericUpDown();
            this.inputMarca = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.botonActualizar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.outputMarca = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.OutputModelo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.outputPrecio = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.outputDescripcion = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.inputIVA = new System.Windows.Forms.NumericUpDown();
            this.botonIVA = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.outputPFinal = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputModelo)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 25);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(537, 448);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.inputDatos);
            this.tabPage1.Controls.Add(this.inputDescripcion);
            this.tabPage1.Controls.Add(this.inputPrecio);
            this.tabPage1.Controls.Add(this.inputModelo);
            this.tabPage1.Controls.Add(this.inputMarca);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(529, 419);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // inputDatos
            // 
            this.inputDatos.Location = new System.Drawing.Point(219, 344);
            this.inputDatos.Name = "inputDatos";
            this.inputDatos.Size = new System.Drawing.Size(106, 48);
            this.inputDatos.TabIndex = 17;
            this.inputDatos.Text = "Cargar Datos";
            this.inputDatos.UseVisualStyleBackColor = true;
            this.inputDatos.Click += new System.EventHandler(this.inputDatos_Click);
            // 
            // inputDescripcion
            // 
            this.inputDescripcion.Location = new System.Drawing.Point(151, 262);
            this.inputDescripcion.Name = "inputDescripcion";
            this.inputDescripcion.Size = new System.Drawing.Size(325, 63);
            this.inputDescripcion.TabIndex = 10;
            this.inputDescripcion.Text = "";
            // 
            // inputPrecio
            // 
            this.inputPrecio.DecimalPlaces = 2;
            this.inputPrecio.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.inputPrecio.Location = new System.Drawing.Point(151, 203);
            this.inputPrecio.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.inputPrecio.Name = "inputPrecio";
            this.inputPrecio.Size = new System.Drawing.Size(325, 22);
            this.inputPrecio.TabIndex = 16;
            // 
            // inputModelo
            // 
            this.inputModelo.Location = new System.Drawing.Point(151, 145);
            this.inputModelo.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.inputModelo.Minimum = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            this.inputModelo.Name = "inputModelo";
            this.inputModelo.Size = new System.Drawing.Size(325, 22);
            this.inputModelo.TabIndex = 15;
            this.inputModelo.Value = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            // 
            // inputMarca
            // 
            this.inputMarca.Location = new System.Drawing.Point(151, 92);
            this.inputMarca.Name = "inputMarca";
            this.inputMarca.Size = new System.Drawing.Size(325, 22);
            this.inputMarca.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 265);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 16);
            this.label6.TabIndex = 13;
            this.label6.Text = "Descripcion";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(57, 203);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Precio";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(57, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 16);
            this.label8.TabIndex = 11;
            this.label8.Text = "Modelo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(57, 92);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 16);
            this.label9.TabIndex = 10;
            this.label9.Text = "Marca";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(52, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 25);
            this.label10.TabIndex = 9;
            this.label10.Text = "CARRO";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.outputPFinal);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.botonIVA);
            this.tabPage2.Controls.Add(this.inputIVA);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.outputDescripcion);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.outputPrecio);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.OutputModelo);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.outputMarca);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.botonActualizar);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(529, 419);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ver datos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // botonActualizar
            // 
            this.botonActualizar.Location = new System.Drawing.Point(7, 7);
            this.botonActualizar.Name = "botonActualizar";
            this.botonActualizar.Size = new System.Drawing.Size(516, 58);
            this.botonActualizar.TabIndex = 0;
            this.botonActualizar.Text = "Refrescar";
            this.botonActualizar.UseVisualStyleBackColor = true;
            this.botonActualizar.Click += new System.EventHandler(this.botonActualizar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Marca";
            // 
            // outputMarca
            // 
            this.outputMarca.AutoSize = true;
            this.outputMarca.Location = new System.Drawing.Point(154, 96);
            this.outputMarca.Name = "outputMarca";
            this.outputMarca.Size = new System.Drawing.Size(45, 16);
            this.outputMarca.TabIndex = 3;
            this.outputMarca.Text = "Marca";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Modelo";
            // 
            // OutputModelo
            // 
            this.OutputModelo.AutoSize = true;
            this.OutputModelo.Location = new System.Drawing.Point(154, 139);
            this.OutputModelo.Name = "OutputModelo";
            this.OutputModelo.Size = new System.Drawing.Size(53, 16);
            this.OutputModelo.TabIndex = 6;
            this.OutputModelo.Text = "Modelo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Precio";
            // 
            // outputPrecio
            // 
            this.outputPrecio.AutoSize = true;
            this.outputPrecio.Location = new System.Drawing.Point(154, 185);
            this.outputPrecio.Name = "outputPrecio";
            this.outputPrecio.Size = new System.Drawing.Size(46, 16);
            this.outputPrecio.TabIndex = 8;
            this.outputPrecio.Text = "Precio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Descripcion";
            // 
            // outputDescripcion
            // 
            this.outputDescripcion.AutoSize = true;
            this.outputDescripcion.Location = new System.Drawing.Point(154, 225);
            this.outputDescripcion.Name = "outputDescripcion";
            this.outputDescripcion.Size = new System.Drawing.Size(79, 16);
            this.outputDescripcion.TabIndex = 10;
            this.outputDescripcion.Text = "Descripcion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "IVA";
            // 
            // inputIVA
            // 
            this.inputIVA.DecimalPlaces = 2;
            this.inputIVA.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.inputIVA.Location = new System.Drawing.Point(157, 265);
            this.inputIVA.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.inputIVA.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.inputIVA.Name = "inputIVA";
            this.inputIVA.Size = new System.Drawing.Size(120, 22);
            this.inputIVA.TabIndex = 12;
            this.inputIVA.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // botonIVA
            // 
            this.botonIVA.Location = new System.Drawing.Point(91, 306);
            this.botonIVA.Name = "botonIVA";
            this.botonIVA.Size = new System.Drawing.Size(108, 34);
            this.botonIVA.TabIndex = 13;
            this.botonIVA.Text = "Calcular Valor";
            this.botonIVA.UseVisualStyleBackColor = true;
            this.botonIVA.Click += new System.EventHandler(this.botonIVA_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(55, 362);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 16);
            this.label11.TabIndex = 14;
            this.label11.Text = "Precio Final";
            // 
            // outputPFinal
            // 
            this.outputPFinal.AutoSize = true;
            this.outputPFinal.Location = new System.Drawing.Point(154, 362);
            this.outputPFinal.Name = "outputPFinal";
            this.outputPFinal.Size = new System.Drawing.Size(78, 16);
            this.outputPFinal.TabIndex = 15;
            this.outputPFinal.Text = "Precio Final";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 502);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputModelo)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button inputDatos;
        private System.Windows.Forms.RichTextBox inputDescripcion;
        private System.Windows.Forms.NumericUpDown inputPrecio;
        private System.Windows.Forms.NumericUpDown inputModelo;
        private System.Windows.Forms.TextBox inputMarca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button botonActualizar;
        private System.Windows.Forms.Label outputPFinal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button botonIVA;
        private System.Windows.Forms.NumericUpDown inputIVA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label outputDescripcion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label outputPrecio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label OutputModelo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label outputMarca;
        private System.Windows.Forms.Label label4;
    }
}

